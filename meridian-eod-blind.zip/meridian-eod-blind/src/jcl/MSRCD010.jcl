//MSRCD010 JOB (MSEC,RC),'RC STREET STMT LOAD',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRCD010 - STREET-SIDE RECON - LOAD THE DEPOSITORY           *
//*            STATEMENTS (PRIOR BUSINESS DAY CLOSE)             *
//*                                                              *
//* STEP005  SORT    COPY OF THE DTC STATEMENT KEEPING ONLY THE  *
//*                  HEADER / DETAIL / TRAILER RECORDS (VB)      *
//*                                                 (RCS010A)    *
//* STEP010  RCB100  DTC STATEMENT LOAD - TRAILER AND SEGMENT    *
//*                  PROOF                          (RCP100A)    *
//* STEP020  RCB110  FED AND EUROCLEAR LOAD (IKJEFT01 - CMD010   *
//*                  ISIN TO CUSIP)                 (RCP110A)    *
//* STEP030  SORT    THE THREE STREET POSITION FILES BY          *
//*                  DEPOSITORY / CUSIP             (RCS010B)    *
//*                                                              *
//* INPUT  : MSEC.PROD.RC.DTCSTMT.RAW(0)  VB 417  FROM DTC       *
//*          MSEC.PROD.RC.FEDSTMT.RAW(0)  FB 100  FROM THE FED   *
//*          MSEC.PROD.RC.EUCSTMT.RAW(0)  FB 150  FROM EUROCLEAR *
//*          (ALL RECEIVED OVERNIGHT BY CONNECT:DIRECT)          *
//* OUTPUT : MSEC.PROD.RC.DTCSTMT.EDIT(+1)                       *
//*          MSEC.PROD.RC.STPOS.DTC(+1) / .FED(+1) / .EUC(+1)    *
//*          MSEC.PROD.RC.STPOS.ALL(+1)   TO MSRCD030            *
//*                                                              *
//* RC     : 0 CLEAN, 4 WARNINGS (UNKNOWN ISIN, SEGMENTS OUT OF  *
//*          BALANCE, REJECTED LINES) - RECON RUNS.              *
//*          8 TRAILER OUT OF BALANCE - STEP030 STILL BUILDS     *
//*          STPOS.ALL BUT THE JOB ENDS NOTOK: CALL THE DTC /    *
//*          FED / EUROCLEAR DESK BEFORE RELEASING MSRCD030.     *
//*          U1005 = STATEMENT IS NOT FOR THE PRIOR BUSINESS DAY *
//*          (OLD FILE RECEIVED) - DO NOT FORCE, GET THE FILE.   *
//* RESTART: DELETE THE (+1) GENERATIONS CREATED, RESTART        *
//*          STEP005.                                            *
//*--------------------------------------------------------------*
//* 1996-03-18 DWB  CHG02101 ORIGINAL - DTC ONLY                 *
//* 1998-01-12 TLM  CHG03880 FED BOOK ENTRY (RCB110)             *
//* 2003-10-06 KAP  CHG11702 EUROCLEAR, STPOS.ALL SORT           *
//* 2011-03-07 SPA  CHG21340 DTC 2011 FORMAT - DROP MEMO RECORDS *
//*                          BEFORE RCB100 (STEP005)             *
//* 2016-05-09 SPA  CHG29344 RCB110 UNDER MSPDB2                 *
//*--------------------------------------------------------------*
//STEP005  EXEC MSPSORT
//SORT.SORTIN  DD DSN=MSEC.PROD.RC.DTCSTMT.RAW(0),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.RC.DTCSTMT.EDIT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=VB,LRECL=417,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(RCS010A),DISP=SHR
//*
//STEP010  EXEC MSPBATCH,PROG=RCB100,COND=(0,NE)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(RCP100A),DISP=SHR
//GO.DTCSTMT   DD DSN=MSEC.PROD.RC.DTCSTMT.EDIT(+1),DISP=SHR
//GO.STPOSOUT  DD DSN=MSEC.PROD.RC.STPOS.DTC(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//*
//STEP020  EXEC MSPDB2,PROG=RCB110,PLAN=MSRCPLN,COND=(8,LT)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(RCP110A),DISP=SHR
//DB2.FEDSTMT  DD DSN=MSEC.PROD.RC.FEDSTMT.RAW(0),DISP=SHR
//DB2.EUCSTMT  DD DSN=MSEC.PROD.RC.EUCSTMT.RAW(0),DISP=SHR
//DB2.FEDOUT   DD DSN=MSEC.PROD.RC.STPOS.FED(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//DB2.EUCOUT   DD DSN=MSEC.PROD.RC.STPOS.EUC(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//*
//STEP030  EXEC MSPSORT,COND=(8,LT)
//SORT.SORTIN  DD DSN=MSEC.PROD.RC.STPOS.DTC(+1),DISP=SHR
//             DD DSN=MSEC.PROD.RC.STPOS.FED(+1),DISP=SHR
//             DD DSN=MSEC.PROD.RC.STPOS.EUC(+1),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.RC.STPOS.ALL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(RCS010B),DISP=SHR
//
