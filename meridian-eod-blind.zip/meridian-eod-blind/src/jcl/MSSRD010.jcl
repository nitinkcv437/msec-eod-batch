//MSSRD010 JOB (MSEC,SR),'SR ACTIVITY VALIDATE',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRD010 - STOCK RECORD - ACTIVITY SORT AND VALIDATION       *
//*                                                              *
//* STEP010  SORT    TC + CA ACTIVITY BY ACCOUNT / CUSIP /       *
//*                  LOCATION / REF / LEG           (SRS010A)    *
//* STEP020  SRB100  ACTIVITY VALIDATION (IKJEFT01 - CMD010)     *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.SRACTV(0)     FROM MSTCD070 (TCB500)   *
//*          MSEC.PROD.CA.SRACTV(0)     FROM MSCAD040 (CAB400)   *
//*          MSEC.PROD.CM.ACCTMAST.KSDS ACCOUNT MASTER           *
//* OUTPUT : MSEC.PROD.SR.ACTV.SORTED(+1)                        *
//*          MSEC.PROD.SR.ACTV.VALID(+1)   TO MSSRD020           *
//*          MSEC.PROD.SR.ACTV.REJECT(+1)  TO OPERATIONS REPAIR  *
//*                                                              *
//* DEPENDS: MSTCD070 AND MSCAD040 (CONTROL-M IN-CONDITIONS)     *
//* RC     : 0 CLEAN, 4 REJECTS OR WARNINGS - REVIEW THE SRB100  *
//*          STATISTICS AND THE REJECT FILE (RUNBOOK SR-010).    *
//*          REJECTED REFERENCES ARE NOT POSTED TODAY.           *
//* RESTART: DELETE SR.ACTV.SORTED(+1), SR.ACTV.VALID(+1) AND    *
//*          SR.ACTV.REJECT(+1) IF CATALOGED, RESTART STEP010.   *
//*--------------------------------------------------------------*
//* 1987-10-12 RJK           ORIGINAL                            *
//* 2010-04-05 SPA  CHG19870 CA.SRACTV CONCATENATED              *
//* 2016-05-09 SPA  CHG29344 SRB100 UNDER MSPDB2                 *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPSORT
//SORT.SORTIN  DD DSN=MSEC.PROD.TC.SRACTV(0),DISP=SHR
//             DD DSN=MSEC.PROD.CA.SRACTV(0),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.SR.ACTV.SORTED(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(SRS010A),DISP=SHR
//*
//STEP020  EXEC MSPDB2,PROG=SRB100,PLAN=MSSRPLN,COND=(4,LT)
//DB2.ACTVIN   DD DSN=MSEC.PROD.SR.ACTV.SORTED(+1),DISP=SHR
//DB2.ACCTMAST DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//DB2.ACTVOK   DD DSN=MSEC.PROD.SR.ACTV.VALID(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//DB2.ACTVREJ  DD DSN=MSEC.PROD.SR.ACTV.REJECT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(10,5),RLSE),
//            DCB=(RECFM=FB,LRECL=250,BLKSIZE=0)
//
