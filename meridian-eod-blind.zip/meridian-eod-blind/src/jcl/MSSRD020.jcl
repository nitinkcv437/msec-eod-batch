//MSSRD020 JOB (MSEC,SR),'SR POSITION POSTING',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRD020 - STOCK RECORD - POSITION POSTING                   *
//*                                                              *
//* STEP010  SRB200  POST VALID ACTIVITY TO THE POSITION MASTER, *
//*                  PENDING SETTLEMENTS, POSTING JOURNAL        *
//*                  CHECKPOINT EVERY 500 LEGS (SRP200A/CMU070)  *
//*                                                              *
//* INPUT  : MSEC.PROD.SR.ACTV.VALID(0)       FROM MSSRD010      *
//* UPDATE : MSEC.PROD.SR.POSITION.KSDS       (DISP=OLD)         *
//*          MSEC.PROD.SR.PENDSETL.KSDS       (DISP=OLD)         *
//*          MSEC.PROD.CM.CHKPT.KSDS          CHECKPOINTS        *
//* OUTPUT : MSEC.PROD.SR.POSTJRNL(+1)        TO MSSRD040/070    *
//*                                                              *
//* CONTROL-M: HOLDS RESOURCE POSMAST EXCLUSIVE.                 *
//* RC     : 0 CLEAN, 4 WARNINGS (FROZEN POSITIONS, DUPLICATE    *
//*          PENDING ROWS), 8 UNPOSTABLE LEGS - CALL SR ON-CALL. *
//* RESTART: DO NOT RESTORE THE KSDS.  DELETE SR.POSTJRNL(+1) IF *
//*          CATALOGED AND RESUBMIT - SRB200 FINDS ITS IN-FLIGHT *
//*          CHECKPOINT AND BYPASSES THE LEGS ALREADY POSTED     *
//*          (RUNBOOK SR-020).  DO NOT CHANGE THE CKPT= CARD ON  *
//*          A RESTART.                                          *
//*--------------------------------------------------------------*
//* 1987-09-01 RJK           ORIGINAL                            *
//* 1993-11-22 DWB  CHG01733 CHECKPOINT / RESTART                *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=SRB200
//GO.ACTVIN    DD DSN=MSEC.PROD.SR.ACTV.VALID(0),DISP=SHR
//GO.POSMAST   DD DSN=MSEC.PROD.SR.POSITION.KSDS,DISP=OLD
//GO.PENDSETL  DD DSN=MSEC.PROD.SR.PENDSETL.KSDS,DISP=OLD
//GO.CHKPTFL   DD DSN=MSEC.PROD.CM.CHKPT.KSDS,DISP=SHR
//GO.POSTJRNL  DD DSN=MSEC.PROD.SR.POSTJRNL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=300,BLKSIZE=0)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(SRP200A),DISP=SHR
//
