//MSRRX300 JOB (MSEC,RR),'RR TRADING ACTIVITY',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRRX300 - REGULATORY REPORTING - TRADING ACTIVITY REQUEST   *
//*            ('BLUE SHEET')  ** AD HOC - NOT IN CONTROL-M **   *
//*                                                              *
//* STEP010  RRB300  ANSWER THE REQUEST CARDS IN RRP300A         *
//*                                                              *
//* INPUT  : MSEC.PROD.CTLCARD(RRP300A)   REQUEST CARDS -        *
//*          COMPLIANCE EDITS THE MEMBER FOR EACH REQUEST        *
//*          MSEC.PROD.TC.TRDHIST.KSDS    (READ ONLY)            *
//*          MSEC.PROD.CM.ACCTMAST.KSDS                          *
//* OUTPUT : MSEC.PROD.RR.BLUESHT(+1)     RESPONSE (RRBLUE) -    *
//*          COMPLIANCE TRANSMITS IT TO THE REQUESTOR            *
//*                                                              *
//* SUBMIT : BY COMPLIANCE OPERATIONS AFTER THE EOD CYCLE (THE   *
//*          TRADE HISTORY IS UPDATED BY MSTCD050).              *
//* RC     : 0 CLEAN, 4 A CARD WAS REJECTED, 8 NO VALID CARD     *
//* RESTART: DELETE RR.BLUESHT(+1), RESUBMIT.                    *
//*--------------------------------------------------------------*
//* 1991-05-13 RJK           ORIGINAL (TAPE)                     *
//* 2006-06-12 KAP  CHG15008 TRDHIST KSDS                        *
//* 2014-03-24 SPA  CHG26615 LISTING                             *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=RRB300
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(RRP300A),DISP=SHR
//GO.TRDHIST   DD DSN=MSEC.PROD.TC.TRDHIST.KSDS,DISP=SHR
//GO.ACCTMAST  DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//GO.BLUEOUT   DD DSN=MSEC.PROD.RR.BLUESHT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(15,15),RLSE),
//            DCB=(RECFM=FB,LRECL=300,BLKSIZE=0)
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
