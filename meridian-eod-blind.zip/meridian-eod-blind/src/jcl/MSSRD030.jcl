//MSSRD030 JOB (MSEC,SR),'SR SETTLEMENT',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRD030 - STOCK RECORD - SETTLEMENT PROCESSING AND FAILS    *
//*                                                              *
//* STEP010  SRB250  SETTLE PENDING ROWS DUE TODAY OR EARLIER,   *
//*                  KEEP ROWS ON THE DTC FAIL LIST OPEN         *
//* STEP020  SRR260  SETTLEMENT FAILS AGING REPORT               *
//*                                                              *
//* INPUT  : MSEC.PROD.SR.FAILREFS(0)     FAIL LIST (FAIL=REF)   *
//*          FROM DTC RECONCILIATION - LAST RECEIVED GENERATION  *
//* UPDATE : MSEC.PROD.SR.PENDSETL.KSDS   (DISP=OLD)             *
//*          MSEC.PROD.SR.POSITION.KSDS   (DISP=OLD)             *
//* OUTPUT : MSEC.PROD.SR.SETTLED(+1)     TO MSSRD040            *
//*          MSEC.PROD.SR.FAILS(+1)       TO STEP020             *
//*                                                              *
//* RC     : 0 CLEAN, 4 FAILS OUTSTANDING OR FAIL CARDS THAT DID *
//*          NOT MATCH A PENDING ROW, 8 PENDING ROW WITHOUT A    *
//*          POSITION (RUNBOOK SR-030)                           *
//* RESTART: RESTORE PENDSETL AND POSITION FROM THE MSSRD020     *
//*          BACKUP IF STEP010 ABENDED AFTER UPDATES, DELETE     *
//*          SR.SETTLED(+1) / SR.FAILS(+1), RESTART STEP010.     *
//*--------------------------------------------------------------*
//* 1991-06-03 DWB  CHG00987 ORIGINAL                            *
//* 2009-12-14 SPA  CHG19002 SETTLED ACTIVITY FOR CASH POSTING   *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=SRB250
//GO.PENDSETL  DD DSN=MSEC.PROD.SR.PENDSETL.KSDS,DISP=OLD
//GO.POSMAST   DD DSN=MSEC.PROD.SR.POSITION.KSDS,DISP=OLD
//GO.SETLOUT   DD DSN=MSEC.PROD.SR.SETTLED(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(20,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//GO.FAILOUT   DD DSN=MSEC.PROD.SR.FAILS(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//GO.SYSIN     DD DSN=MSEC.PROD.SR.FAILREFS(0),DISP=SHR
//*
//STEP020  EXEC MSPBATCH,PROG=SRR260,COND=(4,LT)
//GO.FAILIN    DD DSN=MSEC.PROD.SR.FAILS(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
