//MSCAD010 JOB (MSEC,CA),'CA ANNOUNCE LOAD',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSCAD010 - CORPORATE ACTIONS - LOAD VENDOR ANNOUNCEMENTS     *
//*                                                              *
//* STEP010  CAB100  VALIDATE THE ANNOUNCEMENT FEED AND APPLY    *
//*                  NEW / UPDATE / CANCEL TO THE EVENT MASTER   *
//*                  (IKJEFT01 - CMD010 SECURITY MASTER)         *
//* STEP020  SORT    VALIDATION RESULTS BY RESULT / VENDOR REF   *
//* STEP030  CAR110  EVENT VALIDATION REPORT                     *
//*                                                              *
//* INPUT  : MSEC.PROD.CA.ANNFEED.RAW(0)   VENDOR FEED           *
//*          MSEC.PROD.CA.EVENT.KSDS       EVENT MASTER (UPDATE) *
//* OUTPUT : MSEC.PROD.CA.ANNVAL(+1)       VALIDATION RESULTS    *
//*          MSEC.PROD.CA.ANNVAL.SORTED(+1)                      *
//*          CAR110 REPORT TO SYSOUT                             *
//*                                                              *
//* RC     : 0 CLEAN, 4 REJECTED ANNOUNCEMENTS (CA OPS REVIEW    *
//*          CAR110), 8 TRAILER/HEADER ERROR OR REJECTS OVER     *
//*          MAXREJ - CALL CA OPERATIONS BEFORE MSCAD020.        *
//*                                                              *
//* RESTART: RERUN FROM STEP010.  ANNOUNCEMENTS ALREADY APPLIED  *
//*          ARE REJECTED V014 (NEW) OR V017 (CANCEL) ON RERUN - *
//*          UPDATES ARE RE-APPLIED.  NO RESTORE NEEDED.         *
//*          DEPENDS ON MSCMD010.  SUCCESSOR MSCAD020.           *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=CAB100
//DB2.ANNFEED  DD DSN=MSEC.PROD.CA.ANNFEED.RAW(0),DISP=SHR
//DB2.CAEVENT  DD DSN=MSEC.PROD.CA.EVENT.KSDS,DISP=OLD
//DB2.CAVALOUT DD DSN=MSEC.PROD.CA.ANNVAL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(15,15),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(CAP100A),DISP=SHR
//*
//STEP020  EXEC MSPSORT,COND=(8,LT)
//SORT.SORTIN  DD DSN=MSEC.PROD.CA.ANNVAL(+1),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.CA.ANNVAL.SORTED(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(15,15),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(CAS010A),DISP=SHR
//*
//STEP030  EXEC MSPBATCH,PROG=CAR110,COND=(8,LT)
//GO.CAVALIN   DD DSN=MSEC.PROD.CA.ANNVAL.SORTED(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*
//
