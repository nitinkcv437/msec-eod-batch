//MSRRI001 JOB (MSEC,RR),'RR INITIALIZE',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRRI001 - REGULATORY AND TAX REPORTING - ONE-TIME           *
//*            INITIALIZATION (NEW SYSTEM, DR REBUILD, QA)       *
//*                                                              *
//* STEP005  IDCAMS   DELETE RR GDG BASES AND TAXYTD (RRI001A)   *
//* STEP010  IDCAMS   DEFINE GDG BASES               (RRI001B)   *
//* STEP020  IDCAMS   DEFINE TAX YEAR-TO-DATE KSDS   (RRI001C)   *
//* STEP030  IDCAMS   REPRO SEED TAX YEAR-TO-DATE    (RRI001D)   *
//* STEP040  IEFBR14  EMPTY FIRST RR.RESERVE GENERATION - THE    *
//*                   RESERVE REPORT READS THE PRIOR (0)         *
//*                                                              *
//* INPUT  : MSEC.PROD.SEED.TAXYTD   (RRTAXY, KEY SEQUENCE)      *
//* OUTPUT : MSEC.PROD.RR.RESERVE/CATSUB/TAXACT/HAIRCUT/BLUESHT  *
//*          GDG BASES, MSEC.PROD.RR.TAXYTD.KSDS                 *
//*                                                              *
//* NOTE   : ** DESTRUCTIVE ** - DELETES THE TAX YEAR-TO-DATE    *
//*          MASTER.  NOT IN CONTROL-M.  CHANGE APPROVAL AND TAX *
//*          OPERATIONS SIGN-OFF REQUIRED.                       *
//* RESTART: FROM THE TOP.                                       *
//*--------------------------------------------------------------*
//* 1995-03-13 DWB  CHG01880  ORIGINAL (RESERVE GDG)             *
//* 2016-10-03 SPA  CHG30112  TAXYTD KSDS, HAIRCUT, TAXACT       *
//* 2019-10-14 MHC  CHG34410  CATSUB                             *
//*--------------------------------------------------------------*
//STEP005  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RRI001A),DISP=SHR
//*
//STEP010  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RRI001B),DISP=SHR
//*
//STEP020  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RRI001C),DISP=SHR
//*
//STEP030  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//SEEDTAXY DD DSN=MSEC.PROD.SEED.TAXYTD,DISP=SHR
//TAXYTD   DD DSN=MSEC.PROD.RR.TAXYTD.KSDS,DISP=OLD
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RRI001D),DISP=SHR
//*
//STEP040  EXEC PGM=IEFBR14,COND=(4,LT)
//RESERVE  DD DSN=MSEC.PROD.RR.RESERVE(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=100,BLKSIZE=0)
//
