//MSMGD030 JOB (MSEC,MG),'MG MARGIN INTEREST',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSMGD030 - MARGIN AND CREDIT - MARGIN INTEREST               *
//*                                                              *
//* STEP010  MGB300  DAILY ACCRUAL ON DEBIT BALANCES; ON THE     *
//*                  MONTH-END CYCLE (DATE CARD M/Q/Y) THE       *
//*                  MONTH'S INTEREST IS CHARGED - GL TXN MINT   *
//*                  (IKJEFT01 - CMD050 GL ACCOUNT MAP)          *
//* STEP020  MGR310  ACCRUAL REPORT AND MONTH-END GL PROOF       *
//*                                                              *
//* INPUT  : MSEC.PROD.MG.REQ(0)         FROM MSMGD010           *
//*          MSEC.PROD.CTLCARD(MGP300A)  BROKER CALL RATE        *
//*          MSEC.PROD.CM.ACCTMAST.KSDS  BRANCH FOR COST CENTER  *
//* UPDATE : MSEC.PROD.MG.INTMTD.KSDS    MONTH TO DATE (OLD)     *
//* OUTPUT : MSEC.PROD.MG.INTACCR(+1)    DAILY ACCRUALS          *
//*          MSEC.PROD.MG.INTCHG(+1)     GL LINES - EMPTY EXCEPT *
//*                                      AT MONTH-END            *
//*                                                              *
//* NOTE   : TREASURY UPDATES MGP300A WHEN THE BROKER CALL RATE  *
//*          CHANGES (RUNBOOK MG-11).                            *
//* RC     : 0 CLEAN, 4 PRIOR MONTH CARRIED FORWARD / GL MAP     *
//*          MISSING / NO RATE CARD.                             *
//* RESTART: MG.INTMTD IS UPDATED IN PLACE.  A RERUN THE SAME    *
//*          DAY ACCRUES NOTHING (ZERO DAYS).  FOR A FAILED      *
//*          MONTH-END POSTING SET FORCE-POST=Y (CHANGE REQD).   *
//*--------------------------------------------------------------*
//* 1996-10-14 LFM  CHG02390  ORIGINAL                           *
//* 2009-12-14 SPA  CHG19002  GL FILE MG.INTCHG, MGR310          *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=MGB300,PLAN=MSMGPLN
//DB2.REQIN    DD DSN=MSEC.PROD.MG.REQ(0),DISP=SHR
//DB2.ACCTMAST DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//DB2.MGINTMTD DD DSN=MSEC.PROD.MG.INTMTD.KSDS,DISP=OLD
//DB2.ACCROUT  DD DSN=MSEC.PROD.MG.INTACCR(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,2),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//DB2.GLOUT    DD DSN=MSEC.PROD.MG.INTCHG(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(MGP300A),DISP=SHR
//*
//STEP020  EXEC MSPBATCH,PROG=MGR310,COND=(4,LT)
//GO.ACCRIN    DD DSN=MSEC.PROD.MG.INTACCR(+1),DISP=SHR
//GO.GLIN      DD DSN=MSEC.PROD.MG.INTCHG(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
