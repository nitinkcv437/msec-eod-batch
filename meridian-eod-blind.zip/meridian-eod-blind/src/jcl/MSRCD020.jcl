//MSRCD020 JOB (MSEC,RC),'RC BAI2 BANK STMT',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRCD020 - STREET-SIDE RECON - SETTLEMENT BANK STATEMENT     *
//*                                                              *
//* STEP010  RCB120  PARSE THE BAI2 STATEMENT OF THE SETTLEMENT  *
//*                  ACCOUNTS INTO BANK TRANSACTIONS  (RCP120A)  *
//*                                                              *
//* INPUT  : MSEC.PROD.RC.BAISTMT.RAW(0)  FB 80  BAI VERSION 2   *
//*          (PRIOR DAY STATEMENT, RECEIVED OVERNIGHT)           *
//* OUTPUT : MSEC.PROD.RC.BANKTXN(+1)     TO MSRCD040            *
//*                                                              *
//* RC     : 0 CLEAN, 4 CONTROL TOTAL / COUNT DIFFERENCES OR     *
//*          UNKNOWN TYPE CODES (WARNING SINCE CHG23121) -       *
//*          THE CASH RECON RUNS.                                *
//*          U1005 = STATEMENT NOT FOR THE PRIOR BUSINESS DAY.   *
//*          U1008 = NO 01 HEADER / 99 TRAILER (FILE TRUNCATED)  *
//*                  - ASK THE BANK TO RESEND.                   *
//* RESTART: DELETE RC.BANKTXN(+1) IF CATALOGED, RESTART STEP010 *
//*--------------------------------------------------------------*
//* 1999-06-14 TLM  CHG05120 ORIGINAL                            *
//* 2012-11-05 SPA  CHG23121 BANK CONVERSION                     *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=RCB120
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(RCP120A),DISP=SHR
//GO.BAISTMT   DD DSN=MSEC.PROD.RC.BAISTMT.RAW(0),DISP=SHR
//GO.BANKTXN   DD DSN=MSEC.PROD.RC.BANKTXN(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//
