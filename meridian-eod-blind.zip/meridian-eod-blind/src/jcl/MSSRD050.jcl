//MSSRD050 JOB (MSEC,SR),'SR VALUATION',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRD050 - STOCK RECORD - DAILY VALUATION                    *
//*                                                              *
//* STEP010  SRB400  PRICE / VALUE EVERY POSITION IN PLACE       *
//*                  (IKJEFT01 - CMD010, CMD020, CMU030, CMU040) *
//* STEP020  SRR410  VALUATION REPORT BY ACCOUNT                 *
//*                  (VALUATION FILE IS ALREADY IN ACCOUNT ORDER)*
//*                                                              *
//* INPUT  : MSEC.PROD.CM.ACCTMAST.KSDS   BRANCH / REP           *
//*          DB2 SECURITY_MASTER, SECURITY_PRICE, FX_RATE        *
//* UPDATE : MSEC.PROD.SR.POSITION.KSDS   (DISP=OLD)             *
//* OUTPUT : MSEC.PROD.SR.VALUATION(+1)   TO MSSRD080 / MSSRM010 *
//*                                                              *
//* DEPENDS: MSCMD005 PRICE LOAD MUST HAVE RUN.                  *
//* RC     : 0 CLEAN, 4 STALE OR MISSING PRICES / FX RATES -     *
//*          VALUATION COMPLETES WITH THE LAST PRICE (SR-050).   *
//* RESTART: RERUNNABLE FROM STEP010 - DELETE VALUATION(+1).     *
//*--------------------------------------------------------------*
//* 1996-04-22 DWB  CHG02215 ORIGINAL                            *
//* 2011-08-29 SPA  CHG22190 STALE PRICE RC 4                    *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=SRB400,PLAN=MSSRPLN
//DB2.POSMAST  DD DSN=MSEC.PROD.SR.POSITION.KSDS,DISP=OLD
//DB2.ACCTMAST DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//DB2.VALOUT   DD DSN=MSEC.PROD.SR.VALUATION(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//*
//STEP020  EXEC MSPBATCH,PROG=SRR410,COND=(4,LT)
//GO.VALIN     DD DSN=MSEC.PROD.SR.VALUATION(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
