//MSTCD099 JOB (MSEC,TC),'TC T+3 FAILS',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//*--------------------------------------------------------------*
//* MSTCD099 - TRADE CAPTURE - AGED OPEN TRADES PAST T+3         *
//*                                                              *
//* STEP010  TCR990  FAILS AGING REPORT FOR THE CAGE             *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.TRDHIST.KSDS      TRADE HISTORY        *
//* OUTPUT : TCR990 REPORT TO SYSOUT                             *
//*                                                              *
//* RUN ON REQUEST FROM THE CAGE SUPERVISOR (SEE TC-RUNBOOK 93-4)*
//*--------------------------------------------------------------*
//STEP010  EXEC PGM=TCR990
//STEPLIB  DD DSN=MSEC.PROD.LOADLIB,DISP=SHR
//DATECARD DD DSN=MSEC.PROD.CM.DATECARD(0),DISP=SHR
//HOLIDAYS DD DSN=MSEC.PROD.CM.HOLIDAYS,DISP=SHR
//AUDITLOG DD DSN=MSEC.PROD.CM.AUDIT.LOG,DISP=MOD
//CTLTOTS  DD DSN=MSEC.PROD.CM.CTLTOTS(0),DISP=MOD
//TRDHIST  DD DSN=MSEC.PROD.TC.TRDHIST.KSDS,DISP=SHR
//RPTFILE  DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//SYSOUT   DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//
