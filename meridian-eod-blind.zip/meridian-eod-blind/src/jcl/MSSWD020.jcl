//MSSWD020 JOB (MSEC,SW),'SW INBOUND STATUS',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSWD020 - SETTLEMENT MESSAGING - INBOUND STATUS AND         *
//*            SETTLEMENT CONFIRMATIONS FROM THE CUSTODIAN       *
//*                                                              *
//* STEP010  SWB200  PARSE MT544-MT547 / MT548, UPDATE THE       *
//*                  INSTRUCTION MASTER, WRITE STATUS EVENTS     *
//* STEP020  IEBGENER  UNKNOWN REFERENCE NOTICE (RC 4 ONLY)      *
//*                                                              *
//* INPUT  : MSEC.PROD.SW.INMSG.RAW(0)      RECEIVED FROM THE    *
//*          SWIFT GATEWAY (CONNECT:DIRECT 05:15)                *
//* UPDATE : MSEC.PROD.SW.INSTR.KSDS                             *
//* OUTPUT : MSEC.PROD.SW.STATEVT(+1)       TO MSSWD030 (SWR210) *
//*                                                              *
//* RC     : 0 CLEAN, 4 UNKNOWN REFERENCES OR FORMAT ERRORS -    *
//*          CALL THE CUSTODIAN SERVICE DESK (RUNBOOK SW-02),    *
//*          8 TOO MANY FORMAT ERRORS - FILE PROBABLY DAMAGED,   *
//*          REQUEST A RESEND BEFORE MSSWD030 IS RELEASED.       *
//* RESTART: SW.INSTR IS UPDATED IN PLACE.  RESTORE IT FROM THE  *
//*          BACKUP TAKEN BEFORE MSSWD010 OR PARTIAL SETTLEMENTS *
//*          ARE ADDED TWICE.  DELETE SW.STATEVT(+1) IF          *
//*          CATALOGED, RESTART STEP010.                         *
//*--------------------------------------------------------------*
//* 1997-11-03 DWB  CHG03390  ORIGINAL                           *
//* 2011-06-20 SPA  CHG21877  UNKNOWN REFERENCE NOTICE STEP020   *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=SWB200
//GO.MSGIN     DD DSN=MSEC.PROD.SW.INMSG.RAW(0),DISP=SHR
//GO.SWINSTR   DD DSN=MSEC.PROD.SW.INSTR.KSDS,DISP=OLD
//GO.STATOUT   DD DSN=MSEC.PROD.SW.STATEVT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(SWP200A),DISP=SHR
//*
// IF (STEP010.RC = 4) THEN
//STEP020  EXEC PGM=IEBGENER
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DUMMY
//SYSUT2   DD SYSOUT=*
//SYSUT1   DD *
*****************************************************************
* MSSWD020 - THE CUSTODIAN SENT STATUS FOR REFERENCES WE DO NOT *
* KNOW, OR MESSAGES THAT COULD NOT BE READ.  SEE SWB200 SYSOUT  *
* AND THE SWR210 REPORT (MSSWD030).  RUNBOOK SW-02.             *
*****************************************************************
/*
// ENDIF
//
