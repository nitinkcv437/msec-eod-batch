//MSSRD080 JOB (MSEC,SR),'SR POSITION REPORT',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRD080 - STOCK RECORD - POSITION REPORT BY BRANCH / REP    *
//*                                                              *
//* STEP010  SORT    VALUATION BY BRANCH/REP/ACCT/CUSIP (SRS080A)*
//* STEP020  SRR210  POSITION REPORT - CLIENTS, FIRM INVENTORY   *
//*                                                              *
//* INPUT  : MSEC.PROD.SR.VALUATION(0)    FROM MSSRD050          *
//* OUTPUT : MSEC.PROD.SR.VALUE.BRSORT(+1)                       *
//*          SRR210 REPORT TO SYSOUT (BRANCH DISTRIBUTION)       *
//*                                                              *
//* RC     : 0                                                   *
//* RESTART: DELETE VALUE.BRSORT(+1), RESTART STEP010.           *
//*--------------------------------------------------------------*
//* 1989-11-06 RJK           ORIGINAL                            *
//* 1996-05-13 DWB  CHG02215 INPUT FROM VALUATION                *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPSORT
//SORT.SORTIN  DD DSN=MSEC.PROD.SR.VALUATION(0),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.SR.VALUE.BRSORT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(SRS080A),DISP=SHR
//*
//STEP020  EXEC MSPBATCH,PROG=SRR210,COND=(4,LT)
//GO.VALIN     DD DSN=MSEC.PROD.SR.VALUE.BRSORT(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
