//MSSRD040 JOB (MSEC,SR),'SR CASH POSTING',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRD040 - STOCK RECORD - CASH POSTING                       *
//*                                                              *
//* STEP010  SRB300  TRADE-DATE CASH FROM THE POSTING JOURNAL,   *
//*                  SETTLE-DATE CASH FROM SRB250 SETTLEMENTS    *
//* STEP020  SORT    CASH ACTIVITY BY ACCOUNT / CCY  (SRS040A)   *
//* STEP030  SRR310  DAILY CASH ACTIVITY REPORT                  *
//*                                                              *
//* INPUT  : MSEC.PROD.SR.POSTJRNL(0)     FROM MSSRD020          *
//*          MSEC.PROD.SR.SETTLED(0)      FROM MSSRD030          *
//* UPDATE : MSEC.PROD.SR.CASHBAL.KSDS    (DISP=OLD)             *
//* OUTPUT : MSEC.PROD.SR.CASHACT(+1)                            *
//*          MSEC.PROD.SR.CASHACT.SORTED(+1)                     *
//*                                                              *
//* RC     : 0 CLEAN, 4 SETTLEMENTS WITHOUT A BALANCE ROW OR     *
//*          PENDING CASH RESET (RUNBOOK SR-040)                 *
//* RESTART: RESTORE CASHBAL FROM MSEC.PROD.BKUP.CASHBAL(0) IF   *
//*          STEP010 ABENDED, DELETE THE (+1) GENERATIONS AND    *
//*          RESTART STEP010.                                    *
//*--------------------------------------------------------------*
//* 1988-02-15 RJK           ORIGINAL                            *
//* 2015-04-20 SPA  CHG28004 CASH ACTIVITY REPORT                *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=SRB300
//GO.JRNLIN    DD DSN=MSEC.PROD.SR.POSTJRNL(0),DISP=SHR
//GO.SETLIN    DD DSN=MSEC.PROD.SR.SETTLED(0),DISP=SHR
//GO.CASHBAL   DD DSN=MSEC.PROD.SR.CASHBAL.KSDS,DISP=OLD
//GO.CASHACT   DD DSN=MSEC.PROD.SR.CASHACT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(20,10),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//*
//STEP020  EXEC MSPSORT,COND=(4,LT)
//SORT.SORTIN  DD DSN=MSEC.PROD.SR.CASHACT(+1),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.SR.CASHACT.SORTED(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(20,10),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(SRS040A),DISP=SHR
//*
//STEP030  EXEC MSPBATCH,PROG=SRR310,COND=(4,LT)
//GO.CASHIN    DD DSN=MSEC.PROD.SR.CASHACT.SORTED(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
