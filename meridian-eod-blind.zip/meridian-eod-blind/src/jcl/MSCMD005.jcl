//MSCMD005 JOB (MSEC,CM),'CM LOAD MARKET DATA',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSCMD005 - COMMON - LOAD THE DAY'S CLOSING PRICES AND FX     *
//*            RATES INTO DB2 (RUNS BEFORE MSCMD010)             *
//*                                                              *
//* STEP010  DSNUTILB LOAD RESUME YES MSEC.SECURITY_PRICE        *
//*                   (CMD005A)                                  *
//* STEP020  DSNUTILB LOAD RESUME YES MSEC.FX_RATE (CMD005B)     *
//*                                                              *
//* INPUT  : MSEC.PROD.CM.PRICES.DAILY(0)   VENDOR PRICE FILE    *
//*          MSEC.PROD.CM.FXRATES.DAILY(0)  TREASURY FX RATES    *
//*          (RECEIVED BY CONNECT:DIRECT BEFORE 17:30)           *
//* OUTPUT : DB2P TABLES MSEC.SECURITY_PRICE, MSEC.FX_RATE       *
//*                                                              *
//* RESTART: A LOAD RESUME THAT FAILED WITH DUPLICATE KEYS       *
//*          LEAVES THE TABLE SPACE IN COPY PENDING - CALL THE   *
//*          DBA ON CALL (RUNBOOK CM-05).  OTHERWISE RESTART     *
//*          FROM THE FAILING STEP.                              *
//*--------------------------------------------------------------*
//* 1996-05-13 DWB  CHG02240  ORIGINAL - PRICES                  *
//* 2004-10-25 KAP  CHG12690  FX RATES                           *
//*--------------------------------------------------------------*
//STEP010  EXEC PGM=DSNUTILB,PARM='DB2P,MSCMD005.PRICES',REGION=0M
//STEPLIB  DD DSN=DSN.DB2P.SDSNLOAD,DISP=SHR
//SYSPRINT DD SYSOUT=*
//UTPRINT  DD SYSOUT=*
//SYSREC   DD DSN=MSEC.PROD.CM.PRICES.DAILY(0),DISP=SHR
//SYSUT1   DD UNIT=SYSDA,SPACE=(CYL,(10,10))
//SORTOUT  DD UNIT=SYSDA,SPACE=(CYL,(10,10))
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(CMD005A),DISP=SHR
//*
//STEP020  EXEC PGM=DSNUTILB,PARM='DB2P,MSCMD005.FXRATES',
//             COND=(4,LT),REGION=0M
//STEPLIB  DD DSN=DSN.DB2P.SDSNLOAD,DISP=SHR
//SYSPRINT DD SYSOUT=*
//UTPRINT  DD SYSOUT=*
//SYSREC   DD DSN=MSEC.PROD.CM.FXRATES.DAILY(0),DISP=SHR
//SYSUT1   DD UNIT=SYSDA,SPACE=(CYL,(1,1))
//SORTOUT  DD UNIT=SYSDA,SPACE=(CYL,(1,1))
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(CMD005B),DISP=SHR
//
