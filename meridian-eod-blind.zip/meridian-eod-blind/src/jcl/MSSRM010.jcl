//MSSRM010 JOB (MSEC,SR),'SR MONTH-END STMTS',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSRM010 - STOCK RECORD - MONTH-END CLIENT STATEMENTS        *
//*            CONTROL-M CALENDAR MSMONEND (LAST BUSINESS DAY)   *
//*                                                              *
//* STEP010  SRB700  STATEMENT EXTRACT - MONTHLY ACCOUNTS, PLUS  *
//*                  QUARTERLY ACCOUNTS ON QUARTER END (IKJEFT01)*
//* STEP020  SORT    EXTRACT BY ACCOUNT / SEQUENCE   (SRS710A)   *
//* STEP030  SRR710  STATEMENT PRINT                             *
//*                                                              *
//* INPUT  : MSEC.PROD.CM.ACCTMAST.KSDS                          *
//*          MSEC.PROD.SR.POSITION.KSDS   (AS VALUED BY MSSRD050)*
//*          MSEC.PROD.SR.CASHBAL.KSDS                           *
//* OUTPUT : MSEC.PROD.SR.STMTEXT(+1)                            *
//*          MSEC.PROD.SR.STMTEXT.SORTED(+1)                     *
//*          STATEMENTS TO SYSOUT (PRINT VENDOR PICKUP)          *
//*                                                              *
//* RC     : 0, 4 NOT A MONTH-END DATE (NOTHING EXTRACTED) OR    *
//*          FX RATES MISSING                                    *
//* RERUN  : ON ANOTHER DAY REPLACE THE DUMMY SYSIN WITH A CARD  *
//*          FORCE=M (OR FORCE=Q FOR QUARTERLY ACCOUNTS TOO).    *
//* RESTART: DELETE THE (+1) GENERATIONS, RESTART STEP010.       *
//*--------------------------------------------------------------*
//* 1990-01-15 RJK           ORIGINAL                            *
//* 2003-09-08 KAP  CHG11562 QUARTERLY CYCLE                     *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=SRB700,PLAN=MSSRPLN
//DB2.ACCTMAST DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//DB2.POSMAST  DD DSN=MSEC.PROD.SR.POSITION.KSDS,DISP=SHR
//DB2.CASHBAL  DD DSN=MSEC.PROD.SR.CASHBAL.KSDS,DISP=SHR
//DB2.STMTOUT  DD DSN=MSEC.PROD.SR.STMTEXT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//DB2.SYSIN    DD DUMMY
//*
//STEP020  EXEC MSPSORT,COND=(4,LT)
//SORT.SORTIN  DD DSN=MSEC.PROD.SR.STMTEXT(+1),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.SR.STMTEXT.SORTED(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(SRS710A),DISP=SHR
//*
//STEP030  EXEC MSPBATCH,PROG=SRR710,COND=(4,LT)
//GO.STMTIN    DD DSN=MSEC.PROD.SR.STMTEXT.SORTED(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
