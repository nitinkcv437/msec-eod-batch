//MSRRD020 JOB (MSEC,RR),'RR EVENT REPORTING',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRRD020 - REGULATORY REPORTING - CONSOLIDATED EVENT         *
//*            REPORTING SUBMISSION (EQUITY TRADES)              *
//*                                                              *
//* STEP010  RRB200  SUBMISSION EXTRACT (IKJEFT01 - CMD010)      *
//* STEP020  RRR210  SUBMISSION CONTROL REPORT / PROOF           *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.TRADES.FINAL(0) FROM MSTCD050          *
//*          MSEC.PROD.CTLCARD(RRP020A)   VERSION / LATE / TEST  *
//* OUTPUT : MSEC.PROD.RR.CATSUB(+1)      PIPE-DELIMITED LINES   *
//*          PICKED UP BY THE TRANSMISSION JOB AT 06:00 (NDM)    *
//*                                                              *
//* DEPENDS: MSTCD050                                            *
//* RC     : 0 CLEAN, 4 WARNINGS (MISSING SYMBOL, LATE EVENTS),  *
//*          8 SUBMISSION DOES NOT PROVE - DO NOT RELEASE, CALL  *
//*          REGULATORY REPORTING ON CALL (RUNBOOK RR-020).      *
//* RESTART: DELETE RR.CATSUB(+1), RESTART STEP010.  A FILE      *
//*          ALREADY TRANSMITTED IS CORRECTED WITH A NEW         *
//*          VERSION NUMBER, NOT RE-SENT.                        *
//*--------------------------------------------------------------*
//* 2019-10-14 MHC  CHG34410 ORIGINAL                            *
//* 2020-06-22 MHC  CHG35015 GO-LIVE, RRR210 PROOF               *
//* 2023-06-12 JLR  CHG38460 RRP020A CONTROL CARDS               *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=RRB200,PLAN=MSRRPLN
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(RRP020A),DISP=SHR
//DB2.TRADEIN  DD DSN=MSEC.PROD.TC.TRADES.FINAL(0),DISP=SHR
//DB2.CATOUT   DD DSN=MSEC.PROD.RR.CATSUB(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(10,5),RLSE),
//            DCB=(RECFM=FB,LRECL=400,BLKSIZE=0)
//*
//STEP020  EXEC MSPBATCH,PROG=RRR210,COND=(4,LT)
//GO.CATIN     DD DSN=MSEC.PROD.RR.CATSUB(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
