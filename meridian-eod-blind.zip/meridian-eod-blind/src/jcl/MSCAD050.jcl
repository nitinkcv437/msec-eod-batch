//MSCAD050 JOB (MSEC,CA),'CA DIVIDEND ACCRUAL',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSCAD050 - CORPORATE ACTIONS - DIVIDEND RECEIVABLE ACCRUAL   *
//*                                                              *
//* STEP010  CAB500  AUTO-REVERSING GL ACCRUAL FOR CALCULATED,   *
//*                  UNPAID ENTITLEMENTS (IKJEFT01 - CMD050 GL   *
//*                  ACCOUNT MAP, CMU040/CMD030 FX)              *
//* STEP020  CAR510  ACCRUAL REPORT                              *
//*                                                              *
//* INPUT  : MSEC.PROD.CA.ENTLMAST.KSDS    ENTITLEMENTS (READ)   *
//*          MSEC.PROD.CA.EVENT.KSDS       EVENT MASTER (READ)   *
//* OUTPUT : MSEC.PROD.CA.ACCRUAL(+1)      GL LINES (SRGLJNL) -  *
//*          ALWAYS CREATED, MERGED BY SRB600 IN MSSRD070        *
//*          MSEC.PROD.CA.ACCRSUM(+1)      ACCRUAL SUMMARY       *
//*          CAR510 REPORT TO SYSOUT                             *
//*                                                              *
//* RC     : 0 CLEAN, 4 GL MAP OR FX RATE NOT FOUND.             *
//* RESTART: MASTERS ARE READ ONLY - RERUN FROM STEP010.         *
//*          SUCCESSOR MSSRD070.                                 *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=CAB500
//DB2.ENTLMAST DD DSN=MSEC.PROD.CA.ENTLMAST.KSDS,DISP=SHR
//DB2.CAEVENT  DD DSN=MSEC.PROD.CA.EVENT.KSDS,DISP=SHR
//DB2.GLOUT    DD DSN=MSEC.PROD.CA.ACCRUAL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,2),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//DB2.ACCSUM   DD DSN=MSEC.PROD.CA.ACCRSUM(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=100,BLKSIZE=0)
//*
//STEP020  EXEC MSPBATCH,PROG=CAR510,COND=(8,LT)
//GO.ACCSUMIN  DD DSN=MSEC.PROD.CA.ACCRSUM(+1),DISP=SHR
//GO.ACCRGL    DD DSN=MSEC.PROD.CA.ACCRUAL(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*
//
