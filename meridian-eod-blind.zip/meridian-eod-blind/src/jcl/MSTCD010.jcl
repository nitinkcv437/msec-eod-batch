//MSTCD010 JOB (MSEC,TC),'TC OMS VALIDATE',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSTCD010 - TRADE CAPTURE - VALIDATE OMS EQUITY FEED          *
//*                                                              *
//* STEP010  TCB100  EDIT THE OMS EXECUTION FILE, RESOLVE SYMBOL *
//*                  TO CUSIP (IKJEFT01 - CMD010 / CMD020)       *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.OMSFEED.RAW(0)    OMS EXECUTIONS       *
//*          MSEC.PROD.CM.ACCTMAST.KSDS     ACCOUNT MASTER       *
//* OUTPUT : MSEC.PROD.TC.OMS.VALID(+1)     VALID TRADES         *
//*          MSEC.PROD.TC.REJECTS.OMS(+1)   REJECTS / WARNINGS   *
//*                                                              *
//* RC     : 0 CLEAN, 4 REJECTS OR PRICE WARNINGS (NORMAL),      *
//*          8 TRAILER OUT OF BALANCE - CALL THE OMS SUPPORT     *
//*          DESK BEFORE RELEASING MSTCD040.                     *
//* RESTART: DELETE TC.OMS.VALID(+1) AND TC.REJECTS.OMS(+1) IF   *
//*          CATALOGED, THEN RESTART FROM STEP010.               *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=TCB100,PLAN=MSTCPLN
//DB2.OMSFEED  DD DSN=MSEC.PROD.TC.OMSFEED.RAW(0),DISP=SHR
//DB2.ACCTMAST DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//DB2.TRADEOUT DD DSN=MSEC.PROD.TC.OMS.VALID(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=400,BLKSIZE=0)
//DB2.REJOUT   DD DSN=MSEC.PROD.TC.REJECTS.OMS(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=450,BLKSIZE=0)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(TCP100A),DISP=SHR
//
