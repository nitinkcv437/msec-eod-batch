//MSCMD010 JOB (MSEC,CM),'CM OPEN BUSINESS DAY',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSCMD010 - COMMON - OPEN THE BUSINESS DAY                    *
//*            FIRST JOB OF THE EOD CYCLE - EVERY OTHER JOB      *
//*            WAITS FOR ITS CONDITION (MSCMD010-ENDED-OK)       *
//*                                                              *
//* STEP010  IEFBR14  NEW EMPTY CONTROL TOTAL FILE CTLTOTS(+1)   *
//*                   FOR THE NEW BUSINESS DAY                   *
//* STEP020  CMB010   ROLL DATECARD(0) TO THE NEXT NYSE BUSINESS *
//*                   DAY, SET CYCLE TYPE D/M/Q/Y, WRITE         *
//*                   DATECARD(+1).  CONTROL CARDS IN CMD010A    *
//*                   (NORMALLY ALL COMMENTED OUT)               *
//*                                                              *
//* INPUT  : MSEC.PROD.CM.DATECARD(0)   YESTERDAY'S DATE CARD    *
//*          MSEC.PROD.CM.HOLIDAYS      EXCHANGE CALENDAR        *
//* OUTPUT : MSEC.PROD.CM.DATECARD(+1)  TODAY'S DATE CARD        *
//*          MSEC.PROD.CM.CTLTOTS(+1)   TODAY'S CONTROL TOTALS   *
//*                                                              *
//* RC     : 0 NORMAL, 4 WARNING (HOLIDAY FILE NOT LOADED FOR    *
//*          NEXT YEAR - NOTIFY OPS SUPPORT), U1005 BAD DATE CARD*
//* RESTART: IF STEP020 FAILED, DELETE THE CTLTOTS GENERATION    *
//*          CREATED BY STEP010 (IT IS THE CURRENT (0)) AND      *
//*          RESTART FROM STEP010.  NEVER RERUN AFTER A GOOD     *
//*          END - THE DATE WOULD ROLL A SECOND TIME (USE        *
//*          RERUN=Y IN CMD010A, RUNBOOK CM-01).                 *
//*--------------------------------------------------------------*
//* 1989-03-14 RJK            ORIGINAL                           *
//* 2009-02-16 SPA  CHG18810  CTLTOTS(+1) ALLOCATED HERE         *
//*--------------------------------------------------------------*
//STEP010  EXEC PGM=IEFBR14
//CTLTOTS  DD DSN=MSEC.PROD.CM.CTLTOTS(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(15,15),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//*
//STEP020  EXEC PGM=CMB010,COND=(0,NE)
//STEPLIB  DD DSN=MSEC.PROD.LOADLIB,DISP=SHR
//DATECARD DD DSN=MSEC.PROD.CM.DATECARD(0),DISP=SHR
//DATEOUT  DD DSN=MSEC.PROD.CM.DATECARD(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=80,BLKSIZE=0)
//HOLIDAYS DD DSN=MSEC.PROD.CM.HOLIDAYS,DISP=SHR
//AUDITLOG DD DSN=MSEC.PROD.CM.AUDIT.LOG,DISP=MOD
//CTLTOTS  DD DSN=MSEC.PROD.CM.CTLTOTS(+1),DISP=MOD
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(CMD010A),DISP=SHR
//SYSOUT   DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//
