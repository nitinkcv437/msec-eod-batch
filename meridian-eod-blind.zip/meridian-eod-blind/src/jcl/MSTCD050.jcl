//MSTCD050 JOB (MSEC,TC),'TC CANCEL CORRECT',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSTCD050 - TRADE CAPTURE - CANCEL / CORRECT, DUPLICATES      *
//*                                                              *
//* STEP010  TCB300  APPLY CANCELS AND CORRECTIONS TO THE TRADE  *
//*                  HISTORY, REJECT SUSPECTED DUPLICATES (D001) *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.TRADES.ENRICHED(0)  FROM MSTCD040      *
//* UPDATE : MSEC.PROD.TC.TRDHIST.KSDS        TRADE HISTORY      *
//* OUTPUT : MSEC.PROD.TC.TRADES.FINAL(+1)    FINAL TRADES       *
//*          MSEC.PROD.TC.REJECTS.CXL(+1)     C0XX / D001        *
//*                                                              *
//* RC     : 0 CLEAN, 4 REJECTS (NORMAL)                         *
//* RESTART: TRDHIST IS UPDATED IN PLACE.  RESTORE IT FROM       *
//*          MSEC.PROD.BKUP.TRDHIST(0) (TAKEN BY MSCMD090) WITH  *
//*          IDCAMS REPRO REPLACE BEFORE RERUNNING, OR EVERY     *
//*          TRADE WILL REJECT C003.                             *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=TCB300
//GO.TRADEIN   DD DSN=MSEC.PROD.TC.TRADES.ENRICHED(0),DISP=SHR
//GO.TRDHIST   DD DSN=MSEC.PROD.TC.TRDHIST.KSDS,DISP=OLD
//GO.TRADEOUT  DD DSN=MSEC.PROD.TC.TRADES.FINAL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=400,BLKSIZE=0)
//GO.REJOUT    DD DSN=MSEC.PROD.TC.REJECTS.CXL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,2),RLSE),
//            DCB=(RECFM=FB,LRECL=450,BLKSIZE=0)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(TCP300A),DISP=SHR
//
