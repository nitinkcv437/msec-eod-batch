//MSRCI001 JOB (MSEC,RC),'RC INITIALIZE',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRCI001 - STREET-SIDE RECON - ONE-TIME INITIALIZATION       *
//*                                                              *
//* STEP005  IDCAMS   DELETE THE RC GDG BASES AND THE BREAK      *
//*                   MASTER                         (RCI001A)   *
//* STEP010  IDCAMS   DEFINE THE RC GDG BASES        (RCI001B)   *
//* STEP020  IDCAMS   DEFINE RC.BRKMAST.KSDS         (RCI001C)   *
//* STEP030  IDCAMS   LOAD THE OPEN BREAKS CARRIED OVER FROM THE *
//*                   CAGE BREAK LOG                 (RCI001D)   *
//*                                                              *
//* INPUT  : MSEC.PROD.SEED.RCBRKMAST  (RCBRKM, KEY SEQUENCE)    *
//* OUTPUT : RC GDG BASES, MSEC.PROD.RC.BRKMAST.KSDS             *
//*                                                              *
//* NOTE   : RUN AFTER MSCMI001.  THE INBOUND STATEMENT GDGS     *
//*          (DTCSTMT/FEDSTMT/EUCSTMT/BAISTMT.RAW) GET THEIR     *
//*          FIRST GENERATION FROM CONNECT:DIRECT BEFORE THE     *
//*          FIRST MSRCD010; SR.SETTLED AND BKUP.POSITION ARE    *
//*          PRIMED BY MSCMI001.                                 *
//*          ** DESTRUCTIVE ** - DELETES THE BREAK HISTORY.      *
//*          NOT IN CONTROL-M.  RUN ONLY WITH CHANGE APPROVAL.   *
//* RESTART: FROM THE TOP.                                       *
//*--------------------------------------------------------------*
//* 1996-03-18 DWB  CHG02101  ORIGINAL                           *
//* 2002-08-19 KAP  CHG10240  BREAK MASTER                       *
//* 2003-10-06 KAP  CHG11702  EUROCLEAR / BAI2 GDGS              *
//* 2013-05-06 SPA  CHG24790  BRKMAST.BKUP GDG                   *
//*--------------------------------------------------------------*
//STEP005  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RCI001A),DISP=SHR
//*
//STEP010  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RCI001B),DISP=SHR
//*
//STEP020  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RCI001C),DISP=SHR
//*
//STEP030  EXEC PGM=IDCAMS,COND=(0,NE)
//SYSPRINT DD SYSOUT=*
//SEEDBRK  DD DSN=MSEC.PROD.SEED.RCBRKMAST,DISP=SHR
//BRKMAST  DD DSN=MSEC.PROD.RC.BRKMAST.KSDS,DISP=OLD
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RCI001D),DISP=SHR
//
