//MSRRD040 JOB (MSEC,RR),'RR NET CAPITAL',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRRD040 - REGULATORY REPORTING - NET CAPITAL HAIRCUTS ON    *
//*            FIRM INVENTORY                                    *
//*                                                              *
//* STEP010  RRB500  HAIRCUT COMPUTATION (IKJEFT01 - CMD010)     *
//* STEP020  RRR510  HAIRCUT SCHEDULE / NET CAPITAL REPORT       *
//*                                                              *
//* INPUT  : MSEC.PROD.SR.POSITION.KSDS   VALUED BY MSSRD050     *
//*          MSEC.PROD.CTLCARD(RRP040A)   TNC= CARD (MONTHLY)    *
//* OUTPUT : MSEC.PROD.RR.HAIRCUT(+1)     (RRHCUT)               *
//*                                                              *
//* DEPENDS: MSSRD050                                            *
//* RC     : 0 CLEAN, 4 WARNINGS (NOT VALUED, NO TNC CARD),      *
//*          8 HAIRCUTS DO NOT RECOMPUTE (RUNBOOK RR-040)        *
//* RESTART: DELETE RR.HAIRCUT(+1), RESTART STEP010.             *
//*--------------------------------------------------------------*
//* 1993-04-19 RJK  CHG01512 ORIGINAL                            *
//* 2014-06-30 SPA  CHG27120 TNC CARD FOR CONCENTRATION          *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=RRB500,PLAN=MSRRPLN
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(RRP040A),DISP=SHR
//DB2.POSMAST  DD DSN=MSEC.PROD.SR.POSITION.KSDS,DISP=SHR
//DB2.HCUTOUT  DD DSN=MSEC.PROD.RR.HAIRCUT(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(15,15),RLSE),
//            DCB=(RECFM=FB,LRECL=150,BLKSIZE=0)
//*
//STEP020  EXEC MSPBATCH,PROG=RRR510,COND=(4,LT)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(RRP040A),DISP=SHR
//GO.HCUTIN    DD DSN=MSEC.PROD.RR.HAIRCUT(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
