//MSSWD010 JOB (MSEC,SW),'SW BUILD INSTRUCTIONS',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSSWD010 - SETTLEMENT MESSAGING - OUTBOUND INSTRUCTIONS      *
//*                                                              *
//* STEP010  SWB050  PRE-VALIDATION OF TODAY'S SETTLEMENT        *
//*                  INSTRUCTIONS FROM TCB500 (IKJEFT01)         *
//* STEP020  SWB100  ISO 15022 MT541/MT543 NEWM/CANC BUILD,      *
//*                  INSTRUCTION MASTER ROWS STATUS SN (IKJEFT01)*
//* STEP030  SWR110  MESSAGE JOURNAL                             *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.SETLINST(0)       FROM MSTCD070        *
//* UPDATE : MSEC.PROD.SW.INSTR.KSDS        INSTRUCTION MASTER   *
//*                                         + SEQUENCE CONTROL   *
//* OUTPUT : MSEC.PROD.SW.INSTVAL(+1)       VALID INSTRUCTIONS   *
//*          MSEC.PROD.SW.INSTREJ(+1)       EXCEPTIONS           *
//*          MSEC.PROD.SW.OUTMSG(+1)        TO THE SWIFT GATEWAY *
//*                                         (CONNECT:DIRECT      *
//*                                         PICKUP 20:30)        *
//*                                                              *
//* RC     : 0 CLEAN, 4 INSTRUCTIONS REJECTED OR NOT SENT -      *
//*          REVIEW THE SWB050 EXCEPTION REPORT (RUNBOOK SW-01), *
//*          8 FROM SWB050 = TOO MANY REJECTS, NOTHING SENT.     *
//* RESTART: SW.INSTR IS UPDATED BY STEP020.  AN INSTRUCTION     *
//*          ALREADY ON SW.INSTR IS NOT SENT AGAIN.  TO RESEND A *
//*          WHOLE DAY RESTORE SW.INSTR FROM THE PREVIOUS BACKUP *
//*          FIRST (SEE RUNBOOK SW-09 - SEQUENCE NUMBERS).       *
//*          DELETE SW.INSTVAL(+1) / INSTREJ(+1) / OUTMSG(+1)    *
//*          IF CATALOGED, RESTART STEP010.                      *
//*--------------------------------------------------------------*
//* 1997-10-06 DWB  CHG03390  ORIGINAL                           *
//* 1998-02-09 DWB  CHG03512  PRE-VALIDATION STEP010             *
//* 2002-11-18 KAP  CHG09977  JOURNAL STEP030                    *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=SWB050,PLAN=MSSWPLN
//DB2.SETLIN   DD DSN=MSEC.PROD.TC.SETLINST(0),DISP=SHR
//DB2.INSTOK   DD DSN=MSEC.PROD.SW.INSTVAL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(10,5),RLSE),
//            DCB=(RECFM=FB,LRECL=250,BLKSIZE=0)
//DB2.INSTREJ  DD DSN=MSEC.PROD.SW.INSTREJ(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=330,BLKSIZE=0)
//DB2.RPTFILE  DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(SWP050A),DISP=SHR
//*
//STEP020  EXEC MSPDB2,PROG=SWB100,PLAN=MSSWPLN,COND=(4,LT)
//DB2.INSTIN   DD DSN=MSEC.PROD.SW.INSTVAL(+1),DISP=SHR
//DB2.SWINSTR  DD DSN=MSEC.PROD.SW.INSTR.KSDS,DISP=OLD
//DB2.MSGOUT   DD DSN=MSEC.PROD.SW.OUTMSG(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=FB,LRECL=120,BLKSIZE=0)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(SWP100A),DISP=SHR
//*
//STEP030  EXEC MSPBATCH,PROG=SWR110,COND=(4,LT)
//GO.MSGIN     DD DSN=MSEC.PROD.SW.OUTMSG(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(SWP110A),DISP=SHR
//
