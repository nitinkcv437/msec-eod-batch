//MSTCD030 JOB (MSEC,TC),'TC MANUAL CARDS',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSTCD030 - TRADE CAPTURE - VALIDATE MANUAL TRADE CARDS       *
//*                                                              *
//* STEP010  TCB120  EDIT THE MANUAL TRADE / CANCEL CARDS KEYED  *
//*                  BY OPERATIONS (IKJEFT01 - CMD010).          *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.MANUAL.CARDS(0)   CARD IMAGES          *
//*          MSEC.PROD.CM.ACCTMAST.KSDS     ACCOUNT MASTER       *
//* OUTPUT : MSEC.PROD.TC.MAN.VALID(+1)     VALID TRADES         *
//*          MSEC.PROD.TC.REJECTS.MAN(+1)   REJECTED CARDS       *
//*                                                              *
//* RC     : 0 CLEAN, 4 CARDS REJECTED - OPS RE-KEY NEXT DAY.    *
//* RESTART: DELETE TC.MAN.VALID(+1) AND TC.REJECTS.MAN(+1) IF   *
//*          CATALOGED, THEN RESTART FROM STEP010.               *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPDB2,PROG=TCB120,PLAN=MSTCPLN
//DB2.MANCARDS DD DSN=MSEC.PROD.TC.MANUAL.CARDS(0),DISP=SHR
//DB2.ACCTMAST DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//DB2.TRADEOUT DD DSN=MSEC.PROD.TC.MAN.VALID(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(15,15),RLSE),
//            DCB=(RECFM=FB,LRECL=400,BLKSIZE=0)
//DB2.REJOUT   DD DSN=MSEC.PROD.TC.REJECTS.MAN(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(TRK,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=450,BLKSIZE=0)
//DB2.SYSIN    DD DSN=MSEC.PROD.CTLCARD(TCP120A),DISP=SHR
//
