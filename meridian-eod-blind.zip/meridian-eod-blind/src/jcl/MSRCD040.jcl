//MSRCD040 JOB (MSEC,RC),'RC CASH RECON',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSRCD040 - STREET-SIDE RECON - SETTLEMENT CASH               *
//*                                                              *
//* STEP005  IDCAMS  BACKUP OF THE BREAK MASTER      (RCI030A)   *
//* STEP010  RCB300  BANK TRANSACTIONS AGAINST THE SETTLED CASH  *
//*                  LEGS, CASH BREAKS TO THE BREAK MASTER       *
//* STEP020  RCR310  CASH RECONCILIATION REPORT, OPEN CASH BREAKS*
//*                                                              *
//* INPUT  : MSEC.PROD.RC.BANKTXN(0)        FROM MSRCD020        *
//*          MSEC.PROD.SR.SETTLED(-1)       YESTERDAY'S SETTLED  *
//*                                         LEGS - MSSRD030 HAS  *
//*                                         ALREADY CATALOGED    *
//*                                         TODAY'S AS (0)       *
//*          MSEC.PROD.CM.ACCTMAST.KSDS     DVP FLAG             *
//* UPDATE : MSEC.PROD.RC.BRKMAST.KSDS                           *
//* OUTPUT : MSEC.PROD.RC.BRKMAST.BKUP(+1)  RESTORE POINT        *
//*          MSEC.PROD.RC.CASHREC(+1)                            *
//*                                                              *
//* DEPENDS: MSRCD020 AND MSSRD030 (CONTROL-M IN-CONDITIONS)     *
//* RC     : 0 ALL MATCHED, 4 UNMATCHED ITEMS (REPORT RUNS).     *
//* RESTART: RESTORE RC.BRKMAST.KSDS FROM RC.BRKMAST.BKUP(0) IF  *
//*          STEP010 RAN, DELETE RC.CASHREC(+1), RESTART STEP005 *
//*--------------------------------------------------------------*
//* 2004-04-19 KAP  CHG12230 ORIGINAL                            *
//* 2005-01-24 KAP  CHG12966 CASH BREAKS / BREAK MASTER BACKUP   *
//* 2024-02-12 NVR  CHG41007 T+1 REVIEW - NO CHANGE              *
//*--------------------------------------------------------------*
//STEP005  EXEC PGM=IDCAMS
//SYSPRINT DD SYSOUT=*
//BRKMAST  DD DSN=MSEC.PROD.RC.BRKMAST.KSDS,DISP=SHR
//BRKBKUP  DD DSN=MSEC.PROD.RC.BRKMAST.BKUP(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(1,1),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//SYSIN    DD DSN=MSEC.PROD.CTLCARD(RCI030A),DISP=SHR
//*
//STEP010  EXEC MSPBATCH,PROG=RCB300,COND=(4,LT)
//GO.BANKTXN   DD DSN=MSEC.PROD.RC.BANKTXN(0),DISP=SHR
//GO.SETLIN    DD DSN=MSEC.PROD.SR.SETTLED(-1),DISP=SHR
//GO.ACCTMAST  DD DSN=MSEC.PROD.CM.ACCTMAST.KSDS,DISP=SHR
//GO.RCBRKMST  DD DSN=MSEC.PROD.RC.BRKMAST.KSDS,DISP=OLD
//GO.CASHREC   DD DSN=MSEC.PROD.RC.CASHREC(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//*
//STEP020  EXEC MSPBATCH,PROG=RCR310,COND=(4,LT)
//GO.CASHREC   DD DSN=MSEC.PROD.RC.CASHREC(+1),DISP=SHR
//GO.RCBRKMST  DD DSN=MSEC.PROD.RC.BRKMAST.KSDS,DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//
