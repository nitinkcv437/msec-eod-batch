//MSCAD040 JOB (MSEC,CA),'CA PAYABLE DATE',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSCAD040 - CORPORATE ACTIONS - PAYABLE DATE PROCESSING       *
//*                                                              *
//* STEP010  CAB400  PAY ENTITLED EVENTS DUE TODAY - CREATE THE  *
//*                  STOCK RECORD ACTIVITY FOR MSSRD010 AND SET  *
//*                  ENTITLEMENTS / EVENTS TO PAID               *
//*                                                              *
//* INPUT  : MSEC.PROD.CA.EVENT.KSDS       EVENT MASTER (UPDATE) *
//*          MSEC.PROD.CA.ENTLMAST.KSDS    ENTITLEMENTS (UPDATE) *
//* OUTPUT : MSEC.PROD.CA.SRACTV(+1)       SR ACTIVITY (SRACTV)  *
//*          THE GENERATION IS ALWAYS CREATED, EMPTY WHEN NO     *
//*          EVENT PAYS - MSSRD010 CONCATENATES CA.SRACTV(0).    *
//*                                                              *
//* RC     : 0 CLEAN, 4 LATE PAYMENT OR ALREADY PAID ROWS.       *
//* RESTART: IF STEP010 ABENDS, RESTORE CA.EVENT.KSDS AND        *
//*          CA.ENTLMAST.KSDS FROM MSEC.PROD.BKUP.* (MSCMD090 OF *
//*          THE PREVIOUS DAY) OR CONFIRM NO EVENT WAS SET TO PD,*
//*          THEN RERUN.  DO NOT RERUN AFTER MSSRD010 HAS RUN -  *
//*          PAID EVENTS ARE NOT SELECTED AGAIN.                 *
//*          SUCCESSORS: MSSRD010 (WITH MSTCD070), MSCAD050.     *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPBATCH,PROG=CAB400
//GO.CAEVENT   DD DSN=MSEC.PROD.CA.EVENT.KSDS,DISP=OLD
//GO.ENTLMAST  DD DSN=MSEC.PROD.CA.ENTLMAST.KSDS,DISP=OLD
//GO.ACTVOUT   DD DSN=MSEC.PROD.CA.SRACTV(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(2,2),RLSE),
//            DCB=(RECFM=FB,LRECL=200,BLKSIZE=0)
//
