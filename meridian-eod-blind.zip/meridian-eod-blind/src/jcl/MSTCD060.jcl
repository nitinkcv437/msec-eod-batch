//MSTCD060 JOB (MSEC,TC),'TC REJECT REPORT',CLASS=A,MSGCLASS=X,
//             MSGLEVEL=(1,1),NOTIFY=&SYSUID
//         JCLLIB ORDER=MSEC.PROD.PROCLIB
//*--------------------------------------------------------------*
//* MSTCD060 - TRADE CAPTURE - REJECT REPORT                     *
//*                                                              *
//* STEP010  SORT    ALL FIVE REJECT FILES BY SOURCE, REJECT     *
//*                  CODE AND TRADE ID.  THE SAME TRADE REJECTED *
//*                  TWICE WITH THE SAME CODE IS PRINTED ONCE.   *
//* STEP020  TCR410  REJECT REPORT FOR THE REPAIR DESK           *
//*                                                              *
//* INPUT  : MSEC.PROD.TC.REJECTS.OMS(0) .FI(0) .MAN(0)          *
//*          MSEC.PROD.TC.REJECTS.ENR(0) .CXL(0)                 *
//* OUTPUT : MSEC.PROD.TC.REJECTS.ALL(+1)                        *
//*          TCR410 REPORT TO SYSOUT                             *
//*                                                              *
//* RC     : 0 NO REJECTS, 4 REJECTS REPORTED (NORMAL)           *
//* RESTART: DELETE TC.REJECTS.ALL(+1) IF CATALOGED AND RESTART  *
//*          FROM STEP010.  NO DOWNSTREAM DEPENDENCY.            *
//*--------------------------------------------------------------*
//STEP010  EXEC MSPSORT
//SORT.SORTIN  DD DSN=MSEC.PROD.TC.REJECTS.OMS(0),DISP=SHR
//             DD DSN=MSEC.PROD.TC.REJECTS.FI(0),DISP=SHR
//             DD DSN=MSEC.PROD.TC.REJECTS.MAN(0),DISP=SHR
//             DD DSN=MSEC.PROD.TC.REJECTS.ENR(0),DISP=SHR
//             DD DSN=MSEC.PROD.TC.REJECTS.CXL(0),DISP=SHR
//SORT.SORTOUT DD DSN=MSEC.PROD.TC.REJECTS.ALL(+1),
//            DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//            SPACE=(CYL,(5,5),RLSE),
//            DCB=(RECFM=FB,LRECL=450,BLKSIZE=0)
//SORT.SYSIN   DD *
* SOURCE / REJECT CODE / TRADE ID - DROP REPEATS OF THE SAME KEY
  SORT FIELDS=(25,3,CH,A,63,4,CH,A,28,16,CH,A)
  SUM FIELDS=NONE
  OPTION EQUALS
  END
/*
//*
//STEP020  EXEC MSPBATCH,PROG=TCR410,COND=(4,LT)
//GO.REJIN     DD DSN=MSEC.PROD.TC.REJECTS.ALL(+1),DISP=SHR
//GO.RPTFILE   DD SYSOUT=*,DCB=(RECFM=FB,LRECL=133,BLKSIZE=0)
//GO.SYSIN     DD DSN=MSEC.PROD.CTLCARD(TCP410A),DISP=SHR
//
