--*******************************************************************
--* MEMBER   : CMTB030                                              *
--* PURPOSE  : MSEC.FX_RATE - USD PER ONE UNIT OF CURRENCY, DAILY.  *
--* ACCESS   : CMD030 (READ) VIA CMU040.  LOADED DAILY BY MSCMD005  *
--*            FROM MSEC.PROD.CM.FXRATES.DAILY(0).                  *
--*----------------------------------------------------------------*
--* 2004-10-25 KAP  CHG12690  ORIGINAL                              *
--*******************************************************************
SET CURRENT SQLID = 'MSECDBA';

CREATE TABLE MSEC.FX_RATE
     ( CCY               CHAR(3)        NOT NULL
     , RATE_DATE         DATE           NOT NULL
     , USD_RATE          DECIMAL(13,8)  NOT NULL
     , CONSTRAINT FXRAT_RATE_CK CHECK (USD_RATE > 0)
     )
       IN MSECDB01.TSFXRAT
       CCSID EBCDIC;

CREATE UNIQUE INDEX MSEC.XFXRAT01
       ON MSEC.FX_RATE (CCY ASC, RATE_DATE DESC)
       USING STOGROUP MSECSG01 PRIQTY 144 SECQTY 48
       CLUSTER
       BUFFERPOOL BP2
       CLOSE NO;

ALTER TABLE MSEC.FX_RATE
      ADD CONSTRAINT FXRAT_PK PRIMARY KEY (CCY, RATE_DATE);

COMMENT ON TABLE MSEC.FX_RATE IS
       'TREASURY FX RATES - USD PER 1 UNIT OF CCY';

COMMIT;
