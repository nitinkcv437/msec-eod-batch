--*******************************************************************
--* MEMBER   : CMTB040                                              *
--* PURPOSE  : MSEC.WHT_RATE - DIVIDEND / INTEREST WITHHOLDING TAX. *
--*            '**' IN HOLDER_CTRY / ISSUER_CTRY = ANY COUNTRY.     *
--*            END_DATE NULL = OPEN ENDED.                          *
--* ACCESS   : CMD040 (READ).  MAINTAINED BY TAX DEPT, RELOADED BY  *
--*            DSNUTILB LOAD REPLACE WHEN TREATY RATES CHANGE.      *
--*----------------------------------------------------------------*
--* 2003-05-19 KAP  CHG11020  ORIGINAL                              *
--* 2008-11-03 SPA  CHG18377  EFF_DATE / END_DATE                   *
--*******************************************************************
SET CURRENT SQLID = 'MSECDBA';

CREATE TABLE MSEC.WHT_RATE
     ( HOLDER_CTRY       CHAR(2)        NOT NULL
     , ISSUER_CTRY       CHAR(2)        NOT NULL
     , INCOME_TYPE       CHAR(2)        NOT NULL
     , TAX_STATUS        CHAR(1)        NOT NULL
     , EFF_DATE          DATE           NOT NULL
     , END_DATE          DATE
     , RATE              DECIMAL(5,4)   NOT NULL
     , TREATY_FLAG       CHAR(1)        NOT NULL WITH DEFAULT 'N'
     , CONSTRAINT WHTRT_RATE_CK CHECK (RATE BETWEEN 0 AND 1)
     , CONSTRAINT WHTRT_DATE_CK
         CHECK (END_DATE IS NULL OR END_DATE >= EFF_DATE)
     )
       IN MSECDB01.TSWHTRT
       CCSID EBCDIC;

CREATE UNIQUE INDEX MSEC.XWHTRT01
       ON MSEC.WHT_RATE (HOLDER_CTRY ASC, ISSUER_CTRY ASC,
                         INCOME_TYPE ASC, TAX_STATUS ASC,
                         EFF_DATE DESC)
       USING STOGROUP MSECSG01 PRIQTY 48 SECQTY 48
       CLUSTER
       BUFFERPOOL BP2
       CLOSE NO;

ALTER TABLE MSEC.WHT_RATE
      ADD CONSTRAINT WHTRT_PK PRIMARY KEY
          (HOLDER_CTRY, ISSUER_CTRY, INCOME_TYPE, TAX_STATUS,
           EFF_DATE);

COMMENT ON TABLE MSEC.WHT_RATE IS
       'WITHHOLDING RATES - MOST SPECIFIC ROW WINS (CMD040)';

COMMIT;
