--*******************************************************************
--* MEMBER   : CMTB020                                              *
--* PURPOSE  : MSEC.SECURITY_PRICE - CLOSING PRICE PER CUSIP / DAY. *
--* ACCESS   : CMD020 (READ).  LOADED DAILY BY MSCMD005 (DSNUTILB   *
--*            LOAD RESUME YES FROM MSEC.PROD.CM.PRICES.DAILY(0)).  *
--*----------------------------------------------------------------*
--* 1996-05-13 DWB  CHG02240  ORIGINAL                              *
--* 2001-04-09 DWB  CHG08130  DECIMALIZATION - PRICE DEC(17,8)      *
--* 2007-10-01 KAP  CHG16633  XSECPR01 INCLUDES PRICE (INDEX ONLY)  *
--*******************************************************************
SET CURRENT SQLID = 'MSECDBA';

CREATE TABLE MSEC.SECURITY_PRICE
     ( CUSIP             CHAR(9)        NOT NULL
     , PRICE_DATE        DATE           NOT NULL
     , PRICE             DECIMAL(17,8)  NOT NULL
     , SOURCE            CHAR(4)        NOT NULL WITH DEFAULT
     , CCY               CHAR(3)        NOT NULL WITH DEFAULT 'USD'
     )
       IN MSECDB01.TSSECPR
       CCSID EBCDIC;

CREATE UNIQUE INDEX MSEC.XSECPR01
       ON MSEC.SECURITY_PRICE (CUSIP ASC, PRICE_DATE DESC)
       INCLUDE (PRICE)
       USING STOGROUP MSECSG01 PRIQTY 14400 SECQTY 7200
       CLUSTER
       BUFFERPOOL BP2
       CLOSE NO;

ALTER TABLE MSEC.SECURITY_PRICE
      ADD CONSTRAINT SECPR_PK PRIMARY KEY (CUSIP, PRICE_DATE);

COMMENT ON TABLE MSEC.SECURITY_PRICE IS
       'CLOSING PRICES - ONE ROW PER CUSIP PER PRICE DATE';

COMMIT;
