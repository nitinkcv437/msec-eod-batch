--*******************************************************************
--* MEMBER   : CMTB050                                              *
--* PURPOSE  : MSEC.GL_ACCOUNT_MAP - GL DEBIT / CREDIT ACCOUNTS BY  *
--*            TRANSACTION CODE, ACCOUNT TYPE, SECURITY TYPE.       *
--*            '**' = ANY.  MOST SPECIFIC ROW WINS (CMD050).        *
--* NOTE     : THE DESCRIPTION COLUMN IS GL_DESC - 'DESC' IS AN SQL *
--*            RESERVED WORD.                                       *
--*----------------------------------------------------------------*
--* 2008-03-10 SPA  CHG17611  ORIGINAL                              *
--*******************************************************************
SET CURRENT SQLID = 'MSECDBA';

CREATE TABLE MSEC.GL_ACCOUNT_MAP
     ( TXN_CODE          CHAR(4)        NOT NULL
     , ACCT_TYPE         CHAR(2)        NOT NULL
     , SEC_TYPE          CHAR(2)        NOT NULL
     , DR_GL             CHAR(10)       NOT NULL
     , CR_GL             CHAR(10)       NOT NULL
     , COST_CENTER       CHAR(6)        NOT NULL WITH DEFAULT
     , GL_DESC           CHAR(30)       NOT NULL WITH DEFAULT
     )
       IN MSECDB01.TSGLMAP
       CCSID EBCDIC;

CREATE UNIQUE INDEX MSEC.XGLMAP01
       ON MSEC.GL_ACCOUNT_MAP (TXN_CODE ASC, ACCT_TYPE ASC,
                               SEC_TYPE ASC)
       USING STOGROUP MSECSG01 PRIQTY 48 SECQTY 48
       CLUSTER
       BUFFERPOOL BP2
       CLOSE NO;

ALTER TABLE MSEC.GL_ACCOUNT_MAP
      ADD CONSTRAINT GLMAP_PK PRIMARY KEY
          (TXN_CODE, ACCT_TYPE, SEC_TYPE);

COMMENT ON TABLE MSEC.GL_ACCOUNT_MAP IS
       'GL ACCOUNT MAP - WILDCARD ** ROWS, MOST SPECIFIC WINS';

COMMIT;
