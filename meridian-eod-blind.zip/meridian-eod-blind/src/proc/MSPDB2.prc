//MSPDB2   PROC PROG=,
//             PLAN=,
//             RGN=0M
//*--------------------------------------------------------------------*
//* PROC     : MSPDB2                                                  *
//* PURPOSE  : GENERIC DB2 BATCH STEP - RUNS &PROG UNDER THE TSO       *
//*            TERMINAL MONITOR (IKJEFT01) ATTACHED TO DB2P.  USED BY  *
//*            EVERY PROGRAM THAT CALLS A DB2 I/O MODULE (CMD0NN)      *
//*            DIRECTLY OR THROUGH CMU040.                             *
//*                                                                    *
//* SYMBOLICS: PROG=  PROGRAM NAME (REQUIRED)                          *
//*            PLAN=  DB2 PLAN - MSTCPLN / MSSRPLN / MSCAPLN / MSCMPLN *
//*                   (CARRIED IN THE STEP ACCOUNTING FIELD FOR DB2    *
//*                   CHARGEBACK; THE PLAN ACTUALLY USED IS THE ONE ON *
//*                   THE RUN COMMAND IN MEMBER &PROG.T)               *
//*            RGN=   REGION (DEFAULT 0M)                              *
//*                                                                    *
//* STEP NAME: DB2                                                     *
//* SYSTSIN  : MSEC.PROD.CTLCARD(<PROG>T) CONTAINS                     *
//*              DSN SYSTEM(DB2P)                                      *
//*              RUN PROGRAM(<PROG>) PLAN(<PLAN>) -                    *
//*                  LIB('MSEC.PROD.LOADLIB')                          *
//*              END                                                   *
//* DDNAMES  : STEPLIB  MSEC.PROD.LOADLIB + DSN.DB2P.SDSNLOAD          *
//*            DATECARD MSEC.PROD.CM.DATECARD(0)                       *
//*            HOLIDAYS MSEC.PROD.CM.HOLIDAYS                          *
//*            AUDITLOG MSEC.PROD.CM.AUDIT.LOG  MOD                    *
//*            CTLTOTS  MSEC.PROD.CM.CTLTOTS(0) MOD                    *
//*            SYSTSPRT, SYSPRINT, SYSOUT, SYSUDUMP, CEEDUMP           *
//*                                                                    *
//* EXAMPLE  : //STEP030  EXEC MSPDB2,PROG=TCB200,PLAN=MSTCPLN         *
//*            //DB2.TRADEIN  DD DSN=MSEC.PROD.TC.TRADES.SORTED(+1),   *
//*            //             DISP=SHR                                 *
//*--------------------------------------------------------------------*
//* 1996-04-22 DWB  CHG02215  ORIGINAL                                 *
//* 2009-02-16 SPA  CHG18810  CTLTOTS GDG (DISP=MOD ON GENERATION 0)   *
//* 2016-05-09 SPA  CHG29344  SYSTSIN FROM CTLCARD(&PROG.T) - INSTREAM *
//*                           DATA IS NOT ALLOWED IN A CATALOGED PROC  *
//*--------------------------------------------------------------------*
//DB2      EXEC PGM=IKJEFT01,DYNAMNBR=20,REGION=&RGN,ACCT=(DB2,&PLAN)
//STEPLIB  DD DSN=MSEC.PROD.LOADLIB,DISP=SHR
//         DD DSN=DSN.DB2P.SDSNLOAD,DISP=SHR
//SYSTSIN  DD DSN=MSEC.PROD.CTLCARD(&PROG.T),DISP=SHR
//DATECARD DD DSN=MSEC.PROD.CM.DATECARD(0),DISP=SHR
//HOLIDAYS DD DSN=MSEC.PROD.CM.HOLIDAYS,DISP=SHR
//AUDITLOG DD DSN=MSEC.PROD.CM.AUDIT.LOG,DISP=MOD
//CTLTOTS  DD DSN=MSEC.PROD.CM.CTLTOTS(0),DISP=MOD
//SYSTSPRT DD SYSOUT=*
//SYSPRINT DD SYSOUT=*
//SYSOUT   DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
