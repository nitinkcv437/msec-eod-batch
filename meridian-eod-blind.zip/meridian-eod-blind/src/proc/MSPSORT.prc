//MSPSORT  PROC WKSPC=50
//*--------------------------------------------------------------------*
//* PROC     : MSPSORT                                                 *
//* PURPOSE  : GENERIC DFSORT STEP.  THE CALLING JOB SUPPLIES          *
//*            SORT.SORTIN, SORT.SORTOUT (OR SORTINNN / OUTFIL DDS)    *
//*            AND SORT.SYSIN.                                         *
//*                                                                    *
//* SYMBOLICS: WKSPC= PRIMARY CYLINDERS PER SORT WORK DATASET (50)     *
//*                                                                    *
//* STEP NAME: SORT                                                    *
//* DDNAMES  : SYSOUT, SORTWK01-03                                     *
//*                                                                    *
//* EXAMPLE  : //STEP010  EXEC MSPSORT                                 *
//*            //SORT.SORTIN  DD DSN=...,DISP=SHR                      *
//*            //SORT.SORTOUT DD DSN=...(+1),DISP=(NEW,CATLG,DELETE),  *
//*            //             DCB=(RECFM=FB,LRECL=400)                 *
//*            //SORT.SYSIN   DD DSN=MSEC.PROD.CTLCARD(TCS010A),       *
//*            //             DISP=SHR                                 *
//*--------------------------------------------------------------------*
//* 1996-04-22 DWB  CHG02215  ORIGINAL                                 *
//*--------------------------------------------------------------------*
//SORT     EXEC PGM=SORT,REGION=0M
//SYSOUT   DD SYSOUT=*
//SORTWK01 DD UNIT=SYSDA,SPACE=(CYL,(&WKSPC,10))
//SORTWK02 DD UNIT=SYSDA,SPACE=(CYL,(&WKSPC,10))
//SORTWK03 DD UNIT=SYSDA,SPACE=(CYL,(&WKSPC,10))
