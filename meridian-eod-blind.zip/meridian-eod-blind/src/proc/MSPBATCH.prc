//MSPBATCH PROC PROG=,
//             RGN=0M
//*--------------------------------------------------------------------*
//* PROC     : MSPBATCH                                                *
//* PURPOSE  : GENERIC BATCH COBOL STEP (NO DB2).  SUPPLIES THE DDS    *
//*            EVERY MERIDIAN EOD PROGRAM NEEDS; THE CALLING JOB ADDS  *
//*            ITS OWN FILES AS GO.DDNAME OVERRIDES / ADDITIONS.       *
//*                                                                    *
//* SYMBOLICS: PROG=  PROGRAM NAME (REQUIRED)                          *
//*            RGN=   REGION (DEFAULT 0M)                              *
//*                                                                    *
//* STEP NAME: GO                                                      *
//* DDNAMES  : STEPLIB  MSEC.PROD.LOADLIB                              *
//*            DATECARD MSEC.PROD.CM.DATECARD(0)       BUSINESS DATE   *
//*            HOLIDAYS MSEC.PROD.CM.HOLIDAYS          FOR CMU010      *
//*            AUDITLOG MSEC.PROD.CM.AUDIT.LOG  MOD    FOR CMU060      *
//*            CTLTOTS  MSEC.PROD.CM.CTLTOTS(0) MOD    FOR CMU080      *
//*            SYSOUT, SYSUDUMP, CEEDUMP               SYSOUT=*        *
//*                                                                    *
//* EXAMPLE  : //STEP010  EXEC MSPBATCH,PROG=CMB090                    *
//*            //GO.RPTFILE DD SYSOUT=*                                *
//*            //GO.SYSIN   DD DSN=MSEC.PROD.CTLCARD(XXNNNA),DISP=SHR  *
//*--------------------------------------------------------------------*
//* 1996-04-22 DWB  CHG02215  ORIGINAL - COMMON DDS FROM EVERY JOB     *
//* 2009-02-16 SPA  CHG18810  CTLTOTS GDG (DISP=MOD ON GENERATION 0)   *
//*--------------------------------------------------------------------*
//GO       EXEC PGM=&PROG,REGION=&RGN
//STEPLIB  DD DSN=MSEC.PROD.LOADLIB,DISP=SHR
//DATECARD DD DSN=MSEC.PROD.CM.DATECARD(0),DISP=SHR
//HOLIDAYS DD DSN=MSEC.PROD.CM.HOLIDAYS,DISP=SHR
//AUDITLOG DD DSN=MSEC.PROD.CM.AUDIT.LOG,DISP=MOD
//CTLTOTS  DD DSN=MSEC.PROD.CM.CTLTOTS(0),DISP=MOD
//SYSOUT   DD SYSOUT=*
//SYSUDUMP DD SYSOUT=*
//CEEDUMP  DD SYSOUT=*
