  /*------------------------------------------------------------------*/
  /* MEMBER  : CMI001J                                                */
  /* IDCAMS - INITIAL LOAD OF THE MASTER FILES FROM THE SEED DATASETS */
  /* (MSCMI001 STEP040).  SEED FILES MUST BE IN KEY SEQUENCE.         */
  /* CHKPT, TRDHIST, PENDSETL AND ENTLMAST START EMPTY.               */
  /* 1996-04-22 DWB  CHG02215  ORIGINAL                               */
  /* 2016-10-03 SPA  CHG30112  CAEVENT                                */
  /*------------------------------------------------------------------*/
  REPRO INFILE(SEEDACCT) OUTFILE(ACCTMAST)
  IF LASTCC > 0 THEN SET MAXCC = 16
  REPRO INFILE(SEEDPOSN) OUTFILE(POSITION)
  IF LASTCC > 0 THEN SET MAXCC = 16
  REPRO INFILE(SEEDCASH) OUTFILE(CASHBAL)
  IF LASTCC > 0 THEN SET MAXCC = 16
  REPRO INFILE(SEEDCAEV) OUTFILE(CAEVENT)
  IF LASTCC > 0 THEN SET MAXCC = 16
