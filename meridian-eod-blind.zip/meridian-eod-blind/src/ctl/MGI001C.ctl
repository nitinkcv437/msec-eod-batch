  /*------------------------------------------------------------------*/
  /* MEMBER  : MGI001C                                                */
  /* IDCAMS - DEFINE THE MARGIN VSAM CLUSTERS (MSMGI001 STEP020)      */
  /* KEYS(LENGTH OFFSET) MATCH MGRULE, MGCALL AND MGINTM.             */
  /* 1996-10-14 LFM  CHG02390  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  DEFINE CLUSTER (NAME(MSEC.PROD.MG.RULES.KSDS)                 -
                  INDEXED                                       -
                  KEYS(8 0)                                     -
                  RECORDSIZE(80 80)                             -
                  FREESPACE(20 10)                              -
                  SHAREOPTIONS(2 3)                             -
                  CYLINDERS(1 1)                                -
                  SPEED)                                        -
         DATA    (NAME(MSEC.PROD.MG.RULES.KSDS.DATA)            -
                  CONTROLINTERVALSIZE(4096))                    -
         INDEX   (NAME(MSEC.PROD.MG.RULES.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.MG.CALLS.KSDS)                 -
                  INDEXED                                       -
                  KEYS(20 0)                                    -
                  RECORDSIZE(150 150)                           -
                  FREESPACE(20 10)                              -
                  SHAREOPTIONS(2 3)                             -
                  CYLINDERS(5 2)                                -
                  SPEED)                                        -
         DATA    (NAME(MSEC.PROD.MG.CALLS.KSDS.DATA)            -
                  CONTROLINTERVALSIZE(4096))                    -
         INDEX   (NAME(MSEC.PROD.MG.CALLS.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.MG.INTMTD.KSDS)                -
                  INDEXED                                       -
                  KEYS(10 0)                                    -
                  RECORDSIZE(100 100)                           -
                  FREESPACE(10 10)                              -
                  SHAREOPTIONS(2 3)                             -
                  CYLINDERS(2 1)                                -
                  SPEED)                                        -
         DATA    (NAME(MSEC.PROD.MG.INTMTD.KSDS.DATA)           -
                  CONTROLINTERVALSIZE(4096))                    -
         INDEX   (NAME(MSEC.PROD.MG.INTMTD.KSDS.INDEX))
