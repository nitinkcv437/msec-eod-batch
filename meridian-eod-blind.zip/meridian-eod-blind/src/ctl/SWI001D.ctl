  /*------------------------------------------------------------------*/
  /* MEMBER  : SWI001D                                                */
  /* IDCAMS - LOAD THE INSTRUCTION MASTER FROM THE SEED (OPEN         */
  /* INSTRUCTIONS CARRIED OVER + SEQUENCE CONTROL ROW).               */
  /* (MSSWI001 STEP030).  SEED MUST BE IN KEY SEQUENCE.               */
  /* 1997-10-06 DWB  CHG03390  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  REPRO INFILE(SEEDSW) OUTFILE(SWINSTR)
  IF LASTCC > 0 THEN SET MAXCC = 16
