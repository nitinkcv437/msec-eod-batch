  /*------------------------------------------------------------------*/
  /* MEMBER  : RRI001C                                                */
  /* IDCAMS - DEFINE THE TAX YEAR-TO-DATE KSDS (MSRRI001 STEP020)     */
  /* KEYS(18 0) = ACCOUNT 10 + TAX YEAR 4 + FORM 4 (RRTAXY).          */
  /* 2016-10-03 SPA  CHG30112  ORIGINAL (WAS A SEQUENTIAL TAPE)       */
  /*------------------------------------------------------------------*/
  DEFINE CLUSTER (NAME(MSEC.PROD.RR.TAXYTD.KSDS)              -
                  INDEXED                                     -
                  KEYS(18 0)                                  -
                  RECORDSIZE(200 200)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(5 2)                              -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.RR.TAXYTD.KSDS.DATA)         -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.RR.TAXYTD.KSDS.INDEX))
