  /*------------------------------------------------------------------*/
  /* MEMBER  : RCI001D                                                */
  /* IDCAMS - INITIAL LOAD OF THE BREAK MASTER FROM THE SEED FILE     */
  /* (MSRCI001 STEP030) - OPEN BREAKS CARRIED OVER FROM THE CAGE LOG. */
  /* THE SEED MUST BE IN KEY SEQUENCE.                                */
  /* 2002-08-19 KAP  CHG10240  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  REPRO INFILE(SEEDBRK) OUTFILE(BRKMAST)
  IF LASTCC > 0 THEN SET MAXCC = 16
