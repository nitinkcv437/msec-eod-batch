  /*------------------------------------------------------------------*/
  /* MEMBER  : RRI001D                                                */
  /* IDCAMS - LOAD THE TAX YEAR-TO-DATE MASTER FROM THE SEED          */
  /* (MSRRI001 STEP030).  THE SEED HOLDS THE YEAR-TO-DATE BOXES AS    */
  /* OF THE CONVERSION DATE AND MUST BE IN KEY SEQUENCE.              */
  /* 2016-10-03 SPA  CHG30112  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  REPRO INFILE(SEEDTAXY) OUTFILE(TAXYTD)
  IF LASTCC > 0 THEN SET MAXCC = 16
