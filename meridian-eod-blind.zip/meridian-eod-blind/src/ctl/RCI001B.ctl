  /*------------------------------------------------------------------*/
  /* MEMBER  : RCI001B                                                */
  /* IDCAMS - DEFINE THE GDG BASES OF THE STREET-SIDE RECONCILIATION  */
  /* (MSRCI001 STEP010).  INBOUND STATEMENTS 10, WORK FILES 7,        */
  /* RESULTS AND BREAK MASTER BACKUPS 14.                             */
  /* 1996-03-18 DWB  CHG02101  ORIGINAL                               */
  /* 2003-10-06 KAP  CHG11702  EUROCLEAR / BAI2 GDGS                  */
  /* 2013-05-06 SPA  CHG24790  BRKMAST.BKUP                           */
  /*------------------------------------------------------------------*/
  DEFINE GDG (NAME(MSEC.PROD.RC.DTCSTMT.RAW)                  -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.DTCSTMT.EDIT)                 -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.FEDSTMT.RAW)                  -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.EUCSTMT.RAW)                  -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.BAISTMT.RAW)                  -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.STPOS.DTC)                    -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.STPOS.FED)                    -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.STPOS.EUC)                    -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.STPOS.ALL)                    -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.BOOKLOC)                      -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.POSREC)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.BANKTXN)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.CASHREC)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RC.BRKMAST.BKUP)                 -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
