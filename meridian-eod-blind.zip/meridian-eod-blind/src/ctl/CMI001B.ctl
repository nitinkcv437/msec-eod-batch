  /*------------------------------------------------------------------*/
  /* MEMBER  : CMI001B                                                */
  /* IDCAMS - DEFINE THE GDG BASES FOR THE EOD CYCLE                  */
  /* (MSCMI001 STEP010).  LIMITS: DAILY WORK FILES 7,                 */
  /* INBOUND FEEDS 10, REJECTS / JOURNALS / BACKUPS 14,               */
  /* DATE CARD, CONTROL TOTALS AND BREAKS 30.                         */
  /* 1996-04-22 DWB  CHG02215  ORIGINAL                               */
  /* 2009-02-16 SPA  CHG18810  CTLTOTS GDG                            */
  /* 2016-10-03 SPA  CHG30112  BKUP GDGS                              */
  /*------------------------------------------------------------------*/
  DEFINE GDG (NAME(MSEC.PROD.CM.DATECARD)                     -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CM.CTLTOTS)                      -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CM.PRICES.DAILY)                 -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CM.FXRATES.DAILY)                -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.OMSFEED.RAW)                  -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.FIFEED.RAW)                   -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.MANUAL.CARDS)                 -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.OMS.VALID)                    -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.FI.VALID)                     -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.MAN.VALID)                    -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.REJECTS.OMS)                  -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.REJECTS.FI)                   -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.REJECTS.MAN)                  -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.REJECTS.ENR)                  -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.REJECTS.CXL)                  -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.REJECTS.ALL)                  -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.TRADES.SORTED)                -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.TRADES.ENRICHED)              -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.TRADES.FINAL)                 -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.BLOTTER.SORTED)               -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.SRACTV)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.TC.SETLINST)                     -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.ACTV.SORTED)                  -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.ACTV.VALID)                   -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.ACTV.REJECT)                  -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.POSTJRNL)                     -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.SETTLED)                      -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.VALUATION)                    -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.POSN.UNLOAD)                  -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.POSN.SORTED)                  -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.BREAKS)                       -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.BREAKS.DETAIL)                -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.BREAKS.ALERT)                 -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.FAILS)                        -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.CASHACT)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.CASHACT.SORTED)               -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.VALUE.BRSORT)                 -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.POSTJRNL.SORTED)              -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.GLSUMM)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.GLJRNL.SORTED)                -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.STMTEXT.SORTED)               -
              LIMIT(3)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.GLJRNL)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.STMTEXT)                      -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SR.FAILREFS)                     -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ANNFEED.RAW)                  -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ANNVAL)                       -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ANNVAL.SORTED)                -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ELIG.RAW)                     -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ELIG)                         -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ENTL)                         -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.SRACTV)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ACCRUAL)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.CA.ACCRSUM)                      -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.ACCTMAST)                   -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.CHKPT)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.TRDHIST)                    -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.POSITION)                   -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.CASHBAL)                    -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.PENDSETL)                   -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.CAEVENT)                    -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.BKUP.ENTLMAST)                   -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
