  /*------------------------------------------------------------------*/
  /* MEMBER  : RRI001B                                                */
  /* IDCAMS - DEFINE THE REGULATORY REPORTING GDG BASES (MSRRI001     */
  /* STEP010).  RESERVE AND HAIRCUT COMPUTATIONS ARE KEPT 30 DAYS     */
  /* (FINOP REVIEW), SUBMISSIONS AND TAX ACTIVITY 14, AD HOC 10.      */
  /* 1995-03-13 DWB  CHG01880  ORIGINAL (RESERVE)                     */
  /* 2016-10-03 SPA  CHG30112  TAX ACTIVITY, HAIRCUT                  */
  /* 2019-10-14 MHC  CHG34410  EVENT REPORTING SUBMISSION             */
  /*------------------------------------------------------------------*/
  DEFINE GDG (NAME(MSEC.PROD.RR.RESERVE)                      -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RR.CATSUB)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RR.TAXACT)                       -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RR.HAIRCUT)                      -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.RR.BLUESHT)                      -
              LIMIT(10)                                       -
              NOEMPTY                                         -
              SCRATCH)
