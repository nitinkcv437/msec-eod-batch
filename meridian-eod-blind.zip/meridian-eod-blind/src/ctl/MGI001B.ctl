  /*------------------------------------------------------------------*/
  /* MEMBER  : MGI001B                                                */
  /* IDCAMS - DEFINE THE MARGIN GDG BASES (MSMGI001 STEP010).         */
  /* LIMITS: WORK / SORTED FILES 7, REQUIREMENT, ACCRUAL, GL AND      */
  /* CONCENTRATION 14, CALL EVENTS 30 (MARGIN DEPT AUDIT - MD-120).   */
  /* 1996-10-14 LFM  CHG02390  ORIGINAL                               */
  /* 2004-03-15 KAP  CHG12230  CALL EVENT GDG                         */
  /* 2011-03-21 SPA  CHG21402  ISSUER CONCENTRATION GDGS              */
  /* 2015-11-30 SPA  CHG28844  MONTHLY MARGIN SUMMARY GDGS            */
  /*------------------------------------------------------------------*/
  DEFINE GDG (NAME(MSEC.PROD.MG.REQ)                            -
              LIMIT(14)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.REQ.SORTED)                     -
              LIMIT(7)                                          -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.POSREQ)                         -
              LIMIT(7)                                          -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.POSREQ.ISSUER)                  -
              LIMIT(7)                                          -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.ISSCONC)                        -
              LIMIT(14)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.ISSCONC.SORTED)                 -
              LIMIT(7)                                          -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.CALLEVT)                        -
              LIMIT(30)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.CALLS.ALERT)                    -
              LIMIT(14)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.INTACCR)                        -
              LIMIT(14)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.INTCHG)                         -
              LIMIT(14)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.MSTMT)                          -
              LIMIT(14)                                         -
              NOEMPTY                                           -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.MG.MSTMT.SORTED)                   -
              LIMIT(7)                                          -
              NOEMPTY                                           -
              SCRATCH)
