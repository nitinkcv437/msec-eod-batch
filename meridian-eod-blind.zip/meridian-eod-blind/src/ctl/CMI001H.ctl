--******************************************************************
-- MEMBER  : CMI001H
-- DSNUTILB LOAD OF MSEC.GL_ACCOUNT_MAP (CMGMLD, 80 BYTES)
-- FROM MSEC.PROD.SEED.GLMAP.  LOAD FIELD GML-DESC -> GL_DESC.
-- 2008-03-10 SPA  CHG17611  ORIGINAL
--******************************************************************
LOAD DATA INDDN(SYSREC) LOG NO REPLACE
     ENFORCE CONSTRAINTS
  INTO TABLE MSEC.GL_ACCOUNT_MAP
   ( TXN_CODE         POSITION(1:4)           CHAR(4)
   , ACCT_TYPE        POSITION(5:6)           CHAR(2)
   , SEC_TYPE         POSITION(7:8)           CHAR(2)
   , DR_GL            POSITION(9:18)          CHAR(10)
   , CR_GL            POSITION(19:28)         CHAR(10)
   , COST_CENTER      POSITION(29:34)         CHAR(6)
   , GL_DESC          POSITION(35:64)         CHAR(30)
   )
