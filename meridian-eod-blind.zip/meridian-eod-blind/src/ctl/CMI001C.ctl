  /*------------------------------------------------------------------*/
  /* MEMBER  : CMI001C                                                */
  /* IDCAMS - DEFINE THE VSAM KSDS CLUSTERS (MSCMI001 STEP020)        */
  /* KEYS(LENGTH OFFSET) MATCH THE RECORD COPYBOOKS.                  */
  /* 1996-04-22 DWB  CHG02215  ORIGINAL                               */
  /* 2006-06-12 KAP  CHG15008  TRDHIST KEY 16                         */
  /* 2016-10-03 SPA  CHG30112  ENTLMAST                               */
  /*------------------------------------------------------------------*/
  DEFINE CLUSTER (NAME(MSEC.PROD.CM.ACCTMAST.KSDS)            -
                  INDEXED                                     -
                  KEYS(10 0)                                  -
                  RECORDSIZE(300 300)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(20 4)                             -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.CM.ACCTMAST.KSDS.DATA)       -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.CM.ACCTMAST.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.CM.CHKPT.KSDS)               -
                  INDEXED                                     -
                  KEYS(16 0)                                  -
                  RECORDSIZE(100 100)                         -
                  FREESPACE(10 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(1 1)                              -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.CM.CHKPT.KSDS.DATA)          -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.CM.CHKPT.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.TC.TRDHIST.KSDS)             -
                  INDEXED                                     -
                  KEYS(16 0)                                  -
                  RECORDSIZE(200 200)                         -
                  FREESPACE(10 5)                             -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(100 20)                           -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.TC.TRDHIST.KSDS.DATA)        -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.TC.TRDHIST.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.SR.POSITION.KSDS)            -
                  INDEXED                                     -
                  KEYS(23 0)                                  -
                  RECORDSIZE(200 200)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(50 10)                            -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.SR.POSITION.KSDS.DATA)       -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.SR.POSITION.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.SR.CASHBAL.KSDS)             -
                  INDEXED                                     -
                  KEYS(13 0)                                  -
                  RECORDSIZE(150 150)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(10 2)                             -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.SR.CASHBAL.KSDS.DATA)        -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.SR.CASHBAL.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.SR.PENDSETL.KSDS)            -
                  INDEXED                                     -
                  KEYS(25 0)                                  -
                  RECORDSIZE(150 150)                         -
                  FREESPACE(30 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(20 4)                             -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.SR.PENDSETL.KSDS.DATA)       -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.SR.PENDSETL.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.CA.EVENT.KSDS)               -
                  INDEXED                                     -
                  KEYS(12 0)                                  -
                  RECORDSIZE(300 300)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(5 1)                              -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.CA.EVENT.KSDS.DATA)          -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.CA.EVENT.KSDS.INDEX))
  DEFINE CLUSTER (NAME(MSEC.PROD.CA.ENTLMAST.KSDS)            -
                  INDEXED                                     -
                  KEYS(26 0)                                  -
                  RECORDSIZE(250 250)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(20 4)                             -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.CA.ENTLMAST.KSDS.DATA)       -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.CA.ENTLMAST.KSDS.INDEX))
