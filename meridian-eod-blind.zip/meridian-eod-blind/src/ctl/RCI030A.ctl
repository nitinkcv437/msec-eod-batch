  /*------------------------------------------------------------------*/
  /* MEMBER  : RCI030A                                                */
  /* IDCAMS - BACKUP OF THE RECONCILIATION BREAK MASTER BEFORE IT IS  */
  /* UPDATED (MSRCD030 STEP005 BEFORE RCB400, MSRCD040 STEP005        */
  /* BEFORE RCB300).  RESTORE WITH REPRO ... REPLACE ON A RERUN.      */
  /* 2013-05-06 SPA  CHG24790  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  REPRO INFILE(BRKMAST) OUTFILE(BRKBKUP)
  /* AN EMPTY MASTER (NO OPEN OR CLOSED BREAKS YET) IS NOT AN ERROR   */
  IF LASTCC = 4 THEN SET MAXCC = 0
