  /*------------------------------------------------------------------*/
  /* MEMBER  : MGI001D                                                */
  /* IDCAMS - LOAD THE MARGIN CLUSTERS FROM THE SEED DATASETS         */
  /* (MSMGI001 STEP030).  SEED FILES MUST BE IN KEY SEQUENCE.         */
  /* THE CALL MASTER AND THE MONTH-TO-DATE INTEREST CARRY STATE FROM  */
  /* THE PREVIOUS SYSTEM - AN EMPTY SEED MEANS NO OPEN CALLS AND NO   */
  /* INTEREST ACCRUED FOR THE CURRENT MONTH.                          */
  /* 1996-10-14 LFM  CHG02390  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  REPRO INFILE(SEEDRULE) OUTFILE(MGRULES)
  IF LASTCC > 0 THEN SET MAXCC = 16
  REPRO INFILE(SEEDCALL) OUTFILE(MGCALLS)
  IF LASTCC > 4 THEN SET MAXCC = 16
  REPRO INFILE(SEEDMTD) OUTFILE(MGINTMTD)
  IF LASTCC > 4 THEN SET MAXCC = 16
