  /*------------------------------------------------------------------*/
  /* MEMBER  : RCI001C                                                */
  /* IDCAMS - DEFINE THE RECONCILIATION BREAK MASTER (MSRCI001        */
  /* STEP020).  KEY = CLASS(2) + DEPOSITORY/CCY(4) + ITEM(16).        */
  /* 2002-08-19 KAP  CHG10240  ORIGINAL                               */
  /*------------------------------------------------------------------*/
  DEFINE CLUSTER (NAME(MSEC.PROD.RC.BRKMAST.KSDS)             -
                  INDEXED                                     -
                  KEYS(22 0)                                  -
                  RECORDSIZE(200 200)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(2 1)                              -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.RC.BRKMAST.KSDS.DATA)        -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.RC.BRKMAST.KSDS.INDEX))
