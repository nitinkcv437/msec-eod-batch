  /*------------------------------------------------------------------*/
  /* MEMBER  : SWI001C                                                */
  /* IDCAMS - DEFINE THE SETTLEMENT INSTRUCTION MASTER                */
  /* (MSSWI001 STEP020).  KEY = SENDER REFERENCE (16).  THE ROW WITH  */
  /* KEY 'SEQCONTROL' HOLDS THE LAST MESSAGE SEQUENCE NUMBER.         */
  /* 1997-10-06 DWB  CHG03390  ORIGINAL                               */
  /* 2003-01-27 KAP  CHG10244  SEQUENCE CONTROL ROW                   */
  /*------------------------------------------------------------------*/
  DEFINE CLUSTER (NAME(MSEC.PROD.SW.INSTR.KSDS)               -
                  INDEXED                                     -
                  KEYS(16 0)                                  -
                  RECORDSIZE(250 250)                         -
                  FREESPACE(20 10)                            -
                  SHAREOPTIONS(2 3)                           -
                  CYLINDERS(30 10)                            -
                  SPEED)                                      -
         DATA    (NAME(MSEC.PROD.SW.INSTR.KSDS.DATA)          -
                  CONTROLINTERVALSIZE(4096))                  -
         INDEX   (NAME(MSEC.PROD.SW.INSTR.KSDS.INDEX))
