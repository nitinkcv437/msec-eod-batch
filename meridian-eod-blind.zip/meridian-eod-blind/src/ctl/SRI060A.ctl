  /*------------------------------------------------------------------*/
  /* MEMBER  : SRI060A                                                */
  /* IDCAMS - UNLOAD THE POSITION MASTER FOR STOCK RECORD BALANCING   */
  /* (MSSRD060 STEP010).  THE UNLOAD IS IN KEY ORDER (ACCOUNT/CUSIP/  */
  /* LOCATION) AND IS RE-SORTED BY CUSIP IN STEP020 (SRS060A).        */
  /* 1988-03-07 RJK  ORIGINAL                                         */
  /* 1996-04-22 DWB  CHG02215  REPRO REPLACES THE SRB490 UNLOAD PGM   */
  /*------------------------------------------------------------------*/
  REPRO INFILE(POSMAST) OUTFILE(POSUNLD)
