  /*------------------------------------------------------------------*/
  /* MEMBER  : SWI001B                                                */
  /* IDCAMS - DEFINE THE SETTLEMENT MESSAGING GDG BASES               */
  /* (MSSWI001 STEP010).  MESSAGE FILES ARE KEPT 30 GENERATIONS FOR   */
  /* THE CUSTODIAN DISPUTE PROCESS (RUNBOOK SW-04), WORK FILES 7.     */
  /* 1997-10-06 DWB  CHG03390  ORIGINAL                               */
  /* 1998-02-09 DWB  CHG03512  INSTVAL / INSTREJ                      */
  /* 1999-03-15 TLM  CHG04890  PENDSTMT                               */
  /* 2008-01-14 SPA  CHG17720  SW.FAILS FOR REG SHO CLOSE-OUT         */
  /*------------------------------------------------------------------*/
  DEFINE GDG (NAME(MSEC.PROD.SW.INSTVAL)                      -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.INSTREJ)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.OUTMSG)                       -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.INMSG.RAW)                    -
              LIMIT(30)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.STATEVT)                      -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.FAILS)                        -
              LIMIT(14)                                       -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.FAILS.SORTED)                 -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.PENDSTMT)                     -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
  DEFINE GDG (NAME(MSEC.PROD.SW.PENDSTMT.SORTED)              -
              LIMIT(7)                                        -
              NOEMPTY                                         -
              SCRATCH)
